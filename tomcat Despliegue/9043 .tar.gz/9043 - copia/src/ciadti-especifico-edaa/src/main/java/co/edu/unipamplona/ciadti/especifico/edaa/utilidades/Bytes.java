package co.edu.unipamplona.ciadti.especifico.edaa.utilidades;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class Bytes {
    /**
     * Método que lee los bytes de un archivo y lo convierte a base64.
     * @param archivo realpath + nombreArchivo + .extensión
     * @return String con base64
     */
    public static String bytesToBase64( String archivo ) throws IOException
    {
        byte[] bytesArchivo;
        byte[] bytesCodificados;
        String strBase64;

        try
        {
            bytesArchivo = Files.readAllBytes( Paths.get( archivo ) );
            bytesCodificados = Base64.getEncoder().encode( bytesArchivo );
            strBase64 = new String( bytesCodificados );
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }

        return strBase64;
    }
}

/*
 *  30/04/2020: FRANCISCO GERALDINO  : CREACIÓN
 *
 */
