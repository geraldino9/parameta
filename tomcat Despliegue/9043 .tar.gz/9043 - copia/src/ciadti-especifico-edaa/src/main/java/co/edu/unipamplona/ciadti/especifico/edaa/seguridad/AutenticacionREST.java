package co.edu.unipamplona.ciadti.especifico.edaa.seguridad;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.Procesos;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;
import co.edu.unipamplona.ciadti.especifico.utilidades.Constantes;
import com.google.gson.Gson;
import com.nimbusds.jose.JOSEException;

import javax.annotation.security.PermitAll;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Path("/logueo")
public class AutenticacionREST {

    @POST
    @Path("/oAuth")
    @PermitAll
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(UsuarioRE usuarioRE, @Context HttpServletRequest request) {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        Token token;

        try {
            if (null == usuarioRE.getUsuario()) {
                return Response.status(Response.Status.UNAUTHORIZED).entity(gson.toJson(Constantes.NOT_FOUND_USER)).build();
            } else if (null == usuarioRE.getContrasena()) {
                return Response.status(Response.Status.UNAUTHORIZED).entity(gson.toJson(Constantes.NOT_FOUND_PASS)).build();
            } else {
                String keySecret = request.getHeader("Public-Key-Pins");

                fachadaAdministrador = FachadaAdministrador.getInstancia();

                usuarioRE = (UsuarioRE) fachadaAdministrador.validarLogin(usuarioRE, keySecret);

                if (null == usuarioRE) {
                    return Response.status(Response.Status.UNAUTHORIZED).entity(gson.toJson("Autorización de acceso denegada.")).build();
                } else if (!usuarioRE.isOk()) {
                    return Response.status(Response.Status.UNAUTHORIZED).entity(gson.toJson("Autorización de acceso denegada.")).build();
                } else {
//                    token = AuthUtils.createToken(request.getRemoteHost(), usuarioRE);
//                    usuarioRE.setToken(token.token);

                    return Response.ok().entity(gson.toJson(usuarioRE)).build();
                }
            }
        } catch (EdaaException e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response requestValido(@Context HttpServletRequest request) {
        FachadaAdministrador fachadaAdministrador;
        RespuestaVO respuestaVO;

        try {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            respuestaVO = new RespuestaVO();
            respuestaVO.setOk(fachadaAdministrador.requestValido(request.getHeader("referer")));
            return Response.ok(respuestaVO).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Procesos.procesarError(e, MediaType.APPLICATION_JSON);
        }
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
