package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.TipoDocumentoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.ValorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class ValorDAO implements IGeneralDAO, IPrintException
{
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "valor", "postgresql");

    /**
     * Crea una nueva instancia de ValorDAO
     *
     * @throws EdaaException EdaaException
     */
    public ValorDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("ValorDAO()", e);
            throw new EdaaException(e.getClass().getName(), "ValorDAO", "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de ValorDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public ValorDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("ValorDAO(Object conexion)", e);
            throw new EdaaException(e.getClass().getName(), "ValorDAO", "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object listar() throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Método que consulta un registro por id en la entidad EDAA.VALOR
     * @param objeto - Objeto con id de valor a consultar.
     * @return Objeto con datos de valor.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public Object buscar( Object objeto ) throws EdaaException
    {
        ValorRE valorRE_Bus = (ValorRE) objeto;
        ValorRE valorRE = null;
        ResultSet rs = null;

        try
        {
            if ( null == valorRE_Bus ) {
                return null;
            }

            api.clear();
            api.addStrSql( "valor.buscarPorId" );
            api.addParameter( new Parameter( valorRE_Bus.getId(), Types.NUMERIC ) );
            rs = (ResultSet) api.executeQuery();

            if ( rs.next() )
            {
                valorRE = new ValorRE();
                valorRE.setId(rs.getString("valo_id"));
                valorRE.setGrvaId(rs.getString("grva_id"));
                valorRE.setDescripcion(rs.getString("valo_descripcion"));
                valorRE.setPuntaje(rs.getDouble("valo_puntaje"));
                valorRE.setAbreviatura(rs.getString("valo_abreviatura"));
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "ValorDAO", "SQL buscar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "ValorDAO", "buscar( Object )", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return valorRE;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error ::> co.edu.unipamplona.ciadti.edaa.bdatos ::> clase ValorDAO ::> function public void close() ::> Exception ::>" + e.getMessage());
        }
    }
}
/*
 *  21/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
