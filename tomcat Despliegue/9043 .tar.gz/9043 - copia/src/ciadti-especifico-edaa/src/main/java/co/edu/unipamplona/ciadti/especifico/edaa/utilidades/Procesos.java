package co.edu.unipamplona.ciadti.especifico.edaa.utilidades;

import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.ErrorVO;
import net.minidev.json.JSONObject;
//import org.json.JSONObject;

import javax.ws.rs.core.Response;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class Procesos {
    public Procesos() {
    }

    public static Response procesarError(Exception ex, String mediaType) {
        return Response.status(500).entity(ex.getMessage()).type(mediaType).build();
    }

    public static Response procesarError(Exception ex, String mediaType, int estado) {
        ErrorVO errorVO = new ErrorVO();
        errorVO.setStatus("" + estado);
        errorVO.setMensaje(ex.getMessage());
        return Response.status(estado).entity(errorVO).type(mediaType).build();
    }

    /**
     * <p>Método que consume servicio web a través de método GET.</p>
     *
     * @param url con el enlace a solicitar.
     * @return String con formato json
     */
    public static String consumirServicioGET(String url) {
        BufferedReader responseBuffer;
        HttpURLConnection httpConnection = null;
        int status;
        OutputStream outputStream;
        String formatoJson = null;
        URL targetUrl;

        try {
            targetUrl = new URL(url);

            httpConnection = (HttpURLConnection) targetUrl.openConnection();
            httpConnection.setDoOutput(true);
            httpConnection.setRequestMethod("GET");
            httpConnection.setRequestProperty("Content-Type", "application/json");
            httpConnection.setRequestProperty("charset", "UTF-8");
            httpConnection.setUseCaches(false);
            status = httpConnection.getResponseCode();

            if (status != 200) {
                System.out.println("Method GET - status: " + status);

                switch (status) {
                    case 404 -> System.out.println("Servicio web no encontrado.");
                    case 500 -> {
                        responseBuffer = new BufferedReader(new InputStreamReader(httpConnection.getErrorStream(), StandardCharsets.UTF_8));
                        System.out.println("Respuesta SW: " + responseBuffer.readLine());
                    }
                    default -> System.out.println("Respuesta de servicio web no controlada.");
                }
            } else {
                responseBuffer = new BufferedReader(new InputStreamReader(httpConnection.getInputStream(), StandardCharsets.UTF_8));
                formatoJson = responseBuffer.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace(System.out);
        } finally {
            if (null != httpConnection)
                httpConnection.disconnect();
        }

        return formatoJson;
    }

    /**
     * <p>Método que consume servicio web a través de método POST.</p>
     *
     * @param url    con el enlace a solicitar.
     * @param params con los correspondientes parámetros de búsqueda.
     * @return String con formato json
     */
    public static String consumirServicioPOST(String url, JSONObject params) {
        BufferedReader responseBuffer;
        HttpURLConnection httpConnection = null;
        int status;
        OutputStream outputStream;
        String formatoJson = null;
        URL targetUrl;

        try {
            targetUrl = new URL(url);

            httpConnection = (HttpURLConnection) targetUrl.openConnection();
            httpConnection.setDoOutput(true);
            httpConnection.setRequestMethod("POST");
            httpConnection.setRequestProperty("Content-Type", "application/json");
            httpConnection.setRequestProperty("charset", "UTF-8");
            httpConnection.setUseCaches(false);
            outputStream = httpConnection.getOutputStream();
            outputStream.write(params.toString().getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
            status = httpConnection.getResponseCode();

            if (status != 200) {
                System.out.println("Method POST - status: " + status);

                switch (status) {
                    case 404 -> System.out.println("Servicio web no encontrado.");
                    case 500 -> {
                        responseBuffer = new BufferedReader(new InputStreamReader(httpConnection.getErrorStream(), StandardCharsets.UTF_8));
                        System.out.println("Respuesta SW: " + responseBuffer.readLine());
                    }
                    default -> System.out.println("Respuesta de servicio web no controlada.");
                }
            } else {
                responseBuffer = new BufferedReader(new InputStreamReader(httpConnection.getInputStream(), StandardCharsets.UTF_8));
                formatoJson = responseBuffer.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace(System.out);
        } finally {
            if (null != httpConnection)
                httpConnection.disconnect();
        }

        return formatoJson;
    }

    /**
     * Método que finaliza la transacción y cierra la conexión.
     * @param conexion de tipo IDefinitionConnection
     * @param estado de tipo boolean
     * @throws EdaaException excepción personalizada del sistema
     */
    /*public static void finTransaccion(IDefinitionConnection conexion, boolean estado ) throws EdaaException
    {
        try {
            if (conexion != null) {
                conexion.finishTransaction( estado );
                conexion.close();
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        }
    }*/

    /**
     * Método que escribe el archivo en el repositorio.
     * @param archivoRE de tipo ArchivoRE
     * @param repositorioRE de tipo RepositorioRE
     * @return boolean con el estado del proceso
     * @throws EdaaException
     */
    /*public static boolean almacenarArchivo(ArchivoRE archivoRE, RepositorioRE repositorioRE ) throws EdaaException
    {
        boolean ok = false;
        ArchivoVO archivoVO;

        try
        {
            archivoVO = new ArchivoVO();
            archivoVO.setIdArchivo( archivoRE.getId() );
            archivoVO.setNombre( archivoRE.getNombreArchivo() );
            archivoVO.setUrl( repositorioRE.getUrl() );
            archivoVO.setArchivo( Base64.decodeBase64( archivoRE.getBase64().getBytes() ) );
            ok = guardarArchivoEnRepositorio( archivoVO, archivoRE.getDirectorios() );
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        }

        return ok;
    }*/

    /**
     * Método que borra el archivo del repositorio.
     * @param archivoRE de tipo ArchivoRE
     * @param repositorioRE de tipo RepositorioRE
     * @return boolean con el estado del proceso
     * @throws EdaaException
     */
    /*public static boolean suprimirArchivo( ArchivoRE archivoRE, RepositorioRE repositorioRE ) throws EdaaException
    {
        boolean ok = false;
        ArchivoVO archivoVO;

        try
        {
            archivoVO = new ArchivoVO();
            archivoVO.setIdArchivo( archivoRE.getId() );
            archivoVO.setNombre( archivoRE.getNombreArchivo() );
            archivoVO.setUrl( repositorioRE.getUrl() );
            ok = eliminarArchivoEnRepositorio( archivoVO, archivoRE.getDirectorios() );
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        }

        return ok;
    }*/

    /**
     * Método que obtiene el archivo del repositorio.
     * @param archivoRE de tipo ArchivoRE
     * @param repositorioRE de tipo RepositorioRE
     * @return boolean con el estado del proceso
     * @throws EdaaException
     */
    /*public static byte[] leerArchivo( ArchivoRE archivoRE, RepositorioRE repositorioRE ) throws EdaaException
    {
        ArchivoVO archivoVO;
        byte[] archivo = null;

        try
        {
            archivoVO = new ArchivoVO();
            archivoVO.setIdArchivo( archivoRE.getId() );
            archivoVO.setNombre( archivoRE.getNombreArchivo() );
            archivoVO.setUrl( repositorioRE.getUrl() );
            archivo = leerArchivoEnRepositorio( archivoVO, archivoRE.getDirectorios() );
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        }

        return archivo;
    }*/
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
