package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

public class EjecucionRE {
    private String scriId;
    private String paquId;
    private String ejec_fecha;

    public EjecucionRE() {
    }

    public String getScriId() {
        return scriId;
    }

    public void setScriId(String scriId) {
        this.scriId = scriId;
    }

    public String getPaquId() {
        return paquId;
    }

    public void setPaquId(String paquId) {
        this.paquId = paquId;
    }

    public String getEjec_fecha() {
        return ejec_fecha;
    }

    public void setEjec_fecha(String ejec_fecha) {
        this.ejec_fecha = ejec_fecha;
    }
}
