package co.edu.unipamplona.ciadti.especifico.edaa.fachadas;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.*;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.mediadores.AdministradorMDR;
import co.edu.unipamplona.ciadti.especifico.edaa.mediadores.EvaluadorMDR;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.CalificacionVO;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.DatosPDFVO;

import java.util.List;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class FachadaAdministrador {
    private static FachadaAdministrador fachadaAdministrador = null;
    private final AdministradorMDR administradorMDR;
    private final EvaluadorMDR evaluadorMDR;

    private FachadaAdministrador() {
        administradorMDR = new AdministradorMDR();
        evaluadorMDR = new EvaluadorMDR();
    }

    /**
     * verifica si una instancia del Singleton FachadaAdministrador ya ha sido
     * creada, si no, se sincroniza la creación del mismo.
     */
    public static void crearFachadaAdministrador() {
        if (null == fachadaAdministrador) {
            synchronized (FachadaAdministrador.class) {
                System.out.println("¡CREANDO SINGLETON co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador!");
                fachadaAdministrador = new FachadaAdministrador();
            }
        }
    }

    /**
     * Retorna la instancia del Singleton FachadaAdministrador.
     *
     * @return Retorna la instancia del Singleton FachadaAdministrador.
     */
    public static FachadaAdministrador getInstancia() {
        crearFachadaAdministrador();
        return fachadaAdministrador;
    }

    /**
     * valida el usuario y contraseña de acceso al aplicativo
     *
     * @return UsuarioRE
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public Object validarLogin(Object object, String keySecret) throws EdaaException {
        return administradorMDR.validarLogin(object, keySecret);
    }

    /**
     * Filtra los roles por usuario
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public Object filtrarRoles(Object object) throws EdaaException {
        return administradorMDR.filtrarRoles(object);
    }

    /**
     * Lista todos los roles
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public Object listarRoles() throws EdaaException {
        return administradorMDR.listarRoles();
    }

    /**
     * Lista todos los usuarios
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public Object listarUsuarios() throws EdaaException {
        return administradorMDR.listarUsuarios();
    }

    /**
     * Inserta un objeto UsuarioRE
     *
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public void insertarUsuario(Object object) throws EdaaException {
        administradorMDR.insertarUsuario(object);
    }

    /**
     * elimina un objeto UsuarioRE
     *
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public void eliminarUsuario(Object object) throws EdaaException {
        administradorMDR.eliminarUsuario(object);
    }

    /**
     * Actualiza un objeto UsuarioRE
     *
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public void actualizarUsuario(Object object) throws EdaaException {
        administradorMDR.actualizarUsuario(object);
    }

    /**
     * Actualiza el usuario y la contraseña de un objeto UsuarioRE
     *
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public void actualizarUsuarioYContrasena(Object object) throws EdaaException {
        administradorMDR.actualizarUsuarioYContrasena(object);
    }

    /**
     * Lista todos los tipo documentos
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public Object listarTipoDocumento() throws EdaaException {
        return administradorMDR.listarTipoDocumento();
    }

    /**
     * Filtra un objeto evaluadoRE por su identificador
     *
     * @throws EdaaException 20-02-2021 - Mario Alejandro Rangel.
     */
    public Object filtrarEvaluado(Object object) throws EdaaException {
        return administradorMDR.filtrarEvaluado(object);
    }


    /**
     * lista los cargos existentes
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Francisco Geraldino
     */
    public Object listarCargos() throws EdaaException {
        return administradorMDR.listarCargos();
    }

    /**
     * lista los evaluados por el año de presentación
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Francisco Geraldino
     */
    public Object listarEvaluadoByAnnioEvaluacion(Object objeto) throws EdaaException {
        return administradorMDR.listarEvaluadoByAnnioEvaluacion(objeto);
    }

    /**
     * lista los evaluados por el año de presentación
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Francisco Geraldino
     */
    public Object listarEvaluadoByCargo(Object objeto) throws EdaaException {
        return administradorMDR.listarEvaluadoByCargo(objeto);
    }

    /**
     * lista los evaluador por el eval_id
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 - Francisco Geraldino
     */
    public Object listarEvaluadorByEval(Object objeto) throws EdaaException {
        return administradorMDR.listarEvaluadorByEval(objeto);
    }

    // Métodos - Jesús Sierra ----------------------------------------------

    /**
     * valida el host request si es válido
     *
     * @return boolean
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public boolean requestValido(String url) throws EdaaException {
        return administradorMDR.requestValido(url);
    }

    /**
     * Lista de evaluados por evaluador
     *
     * @return List
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public List<UsuarioRE> listarEvaluadosByEvaluador(EvaluadorRE evaluadorRE) throws EdaaException {
        return evaluadorMDR.listarEvaluadosByEvaluador(evaluadorRE);
    }

    /**
     * Objeto FormularioRE por evaluado
     *
     * @return FormularioRE
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public FormularioRE formularioByEvaluado(EvaluadoRE evaluadoRE) throws EdaaException {
        return evaluadorMDR.formularioByEvaluado(evaluadoRE);
    }

    /**
     * Registra la calificación
     *
     * @return String
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public String registrarCalificacion(CalificacionVO calificacionVO) throws EdaaException {
        return evaluadorMDR.registrarCalificacion(calificacionVO);
    }

    public String registrarPuntaje(PuntajeRE puntajeRE) throws EdaaException {
        return administradorMDR.registrarPuntaje(puntajeRE);
    }
    // Fin métodos - Jesús Sierra ----------------------------------------------

    public Object generarDatosPdf(DatosPDFVO datos) throws EdaaException {
        return administradorMDR.generarDatosPdf(datos);
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *  20/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : MODIFICACIÓN
 *
 */
