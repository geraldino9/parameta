package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import java.sql.Timestamp;

public class FormularioPreguntaRE {
    private String id;
    private String formId;
    private String pregId;
    private Short orden;
    private String registradoPor;
    private Timestamp fechaRegistro;
    private boolean ok;
    private FormularioRE formularioRE;
    private PreguntaRE preguntaRE;
    private CalificacionRE calificacionRE;

    public FormularioPreguntaRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getPregId() {
        return pregId;
    }

    public void setPregId(String pregId) {
        this.pregId = pregId;
    }

    public Short getOrden() {
        return orden;
    }

    public void setOrden(Short orden) {
        this.orden = orden;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public FormularioRE getFormularioRE() {
        return formularioRE;
    }

    public void setFormularioRE(FormularioRE formularioRE) {
        this.formularioRE = formularioRE;
    }

    public PreguntaRE getPreguntaRE() {
        return preguntaRE;
    }

    public void setPreguntaRE(PreguntaRE preguntaRE) {
        this.preguntaRE = preguntaRE;
    }

    public CalificacionRE getCalificacionRE() {
        return calificacionRE;
    }

    public void setCalificacionRE(CalificacionRE calificacionRE) {
        this.calificacionRE = calificacionRE;
    }
}
