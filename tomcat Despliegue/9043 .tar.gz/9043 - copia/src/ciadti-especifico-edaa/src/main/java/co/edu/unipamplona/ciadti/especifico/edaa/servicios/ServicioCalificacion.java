package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.Procesos;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.CalificacionVO;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Path("/calificaciones")
public class ServicioCalificacion
{
    @POST
    // @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar( CalificacionVO calificacionVO )
    {
        try
        {
            if ( null == calificacionVO || null == calificacionVO.getRespuestas() || 0 == calificacionVO.getRespuestas().size() ) {
                throw new EdaaException( "Datos requeridos", "Faltan datos de respuestas." );
            }

            FachadaAdministrador fachadaAdministrador = FachadaAdministrador.getInstancia();
            String proceso = fachadaAdministrador.registrarCalificacion( calificacionVO );

            if ( "REGISTRADO".equals( proceso ) )
            {
                RespuestaVO respuestaVO = new RespuestaVO();
                respuestaVO.setEstado( 200 );
                respuestaVO.setOk( true );
                respuestaVO.setProceso( "registrar evaluación" );
                return Response.ok( respuestaVO ).build();
            }
            else {
                throw new EdaaException( "Error", "No se ha podido registrar su solicitud.", "503" );
            }
        } catch (EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }
}
/*
 *  21/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
