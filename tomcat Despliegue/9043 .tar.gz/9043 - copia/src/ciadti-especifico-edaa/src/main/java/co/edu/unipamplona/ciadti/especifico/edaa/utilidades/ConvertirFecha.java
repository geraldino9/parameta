package co.edu.unipamplona.ciadti.especifico.edaa.utilidades;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.sql.Timestamp;

public class ConvertirFecha {

    public static Date stringToDate(String strDate, String format) {
        Date date = null;
        try {
            date = new SimpleDateFormat(format).parse(strDate);
        } catch (Exception ex) {
            System.out.println("Error ::> stringToDate(String strDate, String format) ::> " + ex.getMessage());
        }
        return date;
    }

    public static Timestamp stringToTimestamp(String strDate, String format) {
        Timestamp timestamp = null;
        try {
            Date date = new SimpleDateFormat(format).parse(strDate);
            timestamp = new Timestamp(date.getTime());
        } catch (Exception ex) {
            System.out.println("Error ::> stringToTimestamp(String strDate, String format) ::> " + ex.getMessage());
        }
        return timestamp;
    }

    public static Calendar stringToCalendar(String strDate, String format) {
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(new SimpleDateFormat(format).parse(strDate));
        } catch (Exception ex) {
            System.out.println("Error ::> stringToCalendar(String strDate, String format) ::> " + ex.getMessage());
        }
        return calendar;
    }

    public static String dateToString(Date date, String format) {
        String strDate = null;
        try {
            strDate = new SimpleDateFormat(format).format(date);
        } catch (Exception ex) {
            System.out.println("Error ::> dateToString(Date date, String format) ::> " + ex.getMessage());
        }
        return strDate;
    }

    public static String timestampToString(Timestamp timestamp, String format) {
        String strDate = null;
        try {
            strDate = new SimpleDateFormat(format).format(new Date(timestamp.getTime()));
        } catch (Exception ex) {
            System.out.println("Error ::> timestampToString(Timestamp timestamp, String format) ::> " + ex.getMessage());
        }
        return strDate;
    }

    public static String calendarToString(Calendar calendar, String format) {
        String strDate = null;
        try {
            strDate = new SimpleDateFormat(format).format(calendar.getTime());
        } catch (Exception ex) {
            System.out.println("Error ::> timestampToString(Timestamp timestamp, String format) ::> " + ex.getMessage());
        }
        return strDate;
    }
}