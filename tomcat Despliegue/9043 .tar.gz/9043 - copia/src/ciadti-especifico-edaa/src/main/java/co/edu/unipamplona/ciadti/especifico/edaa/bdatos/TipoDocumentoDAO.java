package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.TipoDocumentoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class TipoDocumentoDAO implements IGeneralDAO, IPrintException {
    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "tipoDocumento", "postgresql");

    /**
     * Crea una nueva instancia de TipoDocumentoDAO
     *
     * @throws EdaaException EdaaException
     */
    public TipoDocumentoDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("TipoDocumentoDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de RolDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public TipoDocumentoDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("TipoDocumentoDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {
    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {
        ArrayList<TipoDocumentoRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("tipoDocumento.listar");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                TipoDocumentoRE tipoDocumentoRE;
                while (rs.next()) {
                    tipoDocumentoRE = new TipoDocumentoRE();
                    tipoDocumentoRE.setId(rs.getString("tido_id"));
                    tipoDocumentoRE.setNombre(rs.getString("tido_nombre"));
                    tipoDocumentoRE.setAbreviatura(rs.getString("tido_abreviatura"));
                    tipoDocumentoRE.setOk(true);

                    list.add(tipoDocumentoRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }
}

/*
 *  19/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : CREACIÓN
 *
 */