package co.edu.unipamplona.ciadti.especifico.edaa.interfaces;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public interface IGeneralDAO
{
    void insertar(Object objeto) throws co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
    void actualizar(Object objeto) throws co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
    void eliminar(Object objeto) throws co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
    Object listar() throws co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
    Object listar(Object objeto) throws co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
    Object buscar(Object objeto) throws co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
    void close();
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
