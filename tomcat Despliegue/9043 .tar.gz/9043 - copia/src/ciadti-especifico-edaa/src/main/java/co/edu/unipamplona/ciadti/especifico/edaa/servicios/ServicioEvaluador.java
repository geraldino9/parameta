package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;
import com.google.gson.Gson;

import javax.annotation.security.PermitAll;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/evaluador")
public class ServicioEvaluador {

    @GET
    @Path("/filtByEval/{evalId}")
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarEvaluadoByAnnioEvaluacion(@PathParam("evalId") String evalId) {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            EvaluadorRE evaluadorRE = new EvaluadorRE();
            evaluadorRE.setEvalId(evalId);
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            Object list = fachadaAdministrador.listarEvaluadorByEval(evaluadorRE);

            if (list != null) {
                return Response.ok(list).build();
            }

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("FILTRAR evaluadores por año");
            respuestaVO.setMensaje("no hay datos");

            return Response.ok(gson.toJson(respuestaVO)).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }
}
