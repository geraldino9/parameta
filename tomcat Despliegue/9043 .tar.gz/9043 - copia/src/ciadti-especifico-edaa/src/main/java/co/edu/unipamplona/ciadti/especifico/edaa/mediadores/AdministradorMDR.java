package co.edu.unipamplona.ciadti.especifico.edaa.mediadores;


import co.edu.unipamplona.ciadti.especifico.edaa.bdatos.*;
import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.*;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.GenerarXMLPDF;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.DatosPDFVO;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolUsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.GeneralVO;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.PoblacionVO;
import co.edu.unipamplona.ciadti.especifico.general.controlador.Log4jInit;
import co.edu.unipamplona.ciadti.especifico.utilidades.Encriptacion;
import especifico.interfaces.IDefinitionConnection;
import org.apache.log4j.Logger;


import javax.naming.Context;
import javax.naming.InitialContext;
import java.math.RoundingMode;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class AdministradorMDR {
    private Context environmentContext;
    private Logger logger;

    public AdministradorMDR() {
        try {
            logger = Log4jInit.logger;
            Context initialContext = new InitialContext();
            environmentContext = (Context) initialContext.lookup("java:comp/env"); // sirve para obtener datos de web.xml
        } catch (Exception e) {
            System.out.println("Error en constructor AdministradorMDR() --> " + e.getMessage());
            e.printStackTrace(System.out);
        }
    }

    /**
     * Valida el login al aplicativo
     *
     * @return UsuarioRE
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public Object validarLogin(Object object, String keySecret) throws EdaaException {
        IGeneralDAO idao = null;
        UsuarioRE usuarioRE = (UsuarioRE) object;
        try {
            String usuario = Encriptacion.desencriptar(usuarioRE.getUsuario(), keySecret);
            String clave = Encriptacion.desencriptar(usuarioRE.getContrasena(), keySecret);

            usuarioRE.setUsuario(usuario);

            idao = new UsuarioDAO();
            usuarioRE = (UsuarioRE) idao.buscar(usuarioRE);

            clave = Encriptacion.getStringMessageDigest(clave, "MD5", 3);

            if (usuarioRE == null) return null;

            if (usuarioRE.getContrasena().equals(clave)) {
                usuarioRE.setOk(true);
                usuarioRE.setContrasena(null);
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return usuarioRE;
    }

    /**
     * Valida el host request para el acceso al aplicativo
     *
     * @return boolean
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public boolean requestValido(String url) throws EdaaException {
        boolean ok = false;
        String referer;
        String urlValida;
        StringTokenizer referersValidos;

        try {
            if (null == url)
                return false;

            urlValida = (String) environmentContext.lookup("requestValido");

            if (null == urlValida)
                return false;

            referersValidos = new StringTokenizer(urlValida, ";");

            while (referersValidos.hasMoreTokens()) {
                referer = referersValidos.nextToken();

                if (url.contains(referer)) {
                    ok = true;
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        }

        return ok;
    }

    /**
     * filtra los roles por usuario
     *
     * @return ArrayList
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public Object filtrarRoles(Object object) throws EdaaException {
        IGeneralDAO idao = null;
        Object list;
        try {
            idao = new RolDAO();
            list = idao.listar(object);
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * Lista todos los roles
     *
     * @return ArrayList
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public Object listarRoles() throws EdaaException {
        IGeneralDAO idao = null;
        Object list;
        try {
            idao = new RolDAO();
            list = idao.listar();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * Lista todos los usuarios
     *
     * @return ArrayList
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public Object listarUsuarios() throws EdaaException {
        IGeneralDAO idao = null;
        Object list;
        try {
            idao = new UsuarioDAO();
            list = idao.listar();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * Inserta un objeto usuario
     *
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public void insertarUsuario(Object object) throws EdaaException {
        IGeneralDAO idao;
        IDefinitionConnection connection = null;
        boolean flag = false;
        try {
            UsuarioRE usuarioRE = (UsuarioRE) object;

            connection = new DefinitionConnectionEdaa();
            connection.startTransaction();

            idao = new UsuarioDAO(connection);
            idao.insertar(usuarioRE);

            flag = usuarioRE.isOk();

            if (flag) {
                String[] cadRol = usuarioRE.getCadenaRoles().split(";");
                idao = new RolUsuarioDAO(connection);

                RolUsuarioRE rolUsuarioRE = new RolUsuarioRE();
                rolUsuarioRE.setUsuarioRE(usuarioRE);
                rolUsuarioRE.setRegistradoPor(usuarioRE.getRegistradoPor());

                RolRE rolRE;

                for (String subRol : cadRol) {
                    rolRE = new RolRE();
                    rolRE.setId(subRol);

                    rolUsuarioRE.setRolRE(rolRE);

                    idao.insertar(rolUsuarioRE);

                    flag = rolUsuarioRE.isOk();

                    if (!flag) throw new EdaaException("Error", "No se pudo insertar los roles del usuario.", "500");
                }

                usuarioRE.setOk(true);
            }
        } catch (EdaaException e) {
            if (e.getStatus().equals("23505"))
                e.printStackTrace(System.out);
            throw new EdaaException(e.getTipo(), e.getMessage(), e.getStatus());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.finishTransaction(flag);
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Elimina un objeto UsuarioRE
     *
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public void eliminarUsuario(Object object) throws EdaaException {
        IGeneralDAO idao;
        IDefinitionConnection connection = null;
        boolean flag = false;
        try {
            UsuarioRE usuarioRE = (UsuarioRE) object;

            connection = new DefinitionConnectionEdaa();
            connection.startTransaction();

            RolUsuarioRE rolUsuarioRE = new RolUsuarioRE();
            rolUsuarioRE.setUsuarioRE(usuarioRE);

            idao = new RolUsuarioDAO(connection);
            idao.eliminar(rolUsuarioRE);

            flag = rolUsuarioRE.isOk();

            if (!flag) throw new EdaaException("Error", "No se pudo eliminar los roles del usuario.", "500");

            idao = new UsuarioDAO(connection);
            idao.eliminar(usuarioRE);

            flag = usuarioRE.isOk();
        } catch (EdaaException e) {
            if (e.getStatus().equals("23503"))
                e.printStackTrace(System.out);
            throw new EdaaException(e.getTipo(), e.getMessage(), e.getStatus());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.finishTransaction(flag);
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Actualiza un objeto UsuarioRE
     *
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public void actualizarUsuario(Object object) throws EdaaException {
        IGeneralDAO idao;
        IDefinitionConnection connection = null;
        boolean flag = false;
        try {
            UsuarioRE usuarioRE = (UsuarioRE) object;

            connection = new DefinitionConnectionEdaa();
            connection.startTransaction();

            idao = new UsuarioDAO(connection);
            idao.actualizar(usuarioRE);

            flag = usuarioRE.isOk();

            if (flag) {
                RolUsuarioRE rolUsuarioRE = new RolUsuarioRE();
                rolUsuarioRE.setUsuarioRE(usuarioRE);

                idao = new RolUsuarioDAO(connection);
                idao.eliminar(rolUsuarioRE);

                flag = rolUsuarioRE.isOk();

                if (flag) {
                    String[] cadRol = usuarioRE.getCadenaRoles().split(";");
                    idao = new RolUsuarioDAO(connection);

                    rolUsuarioRE = new RolUsuarioRE();
                    rolUsuarioRE.setUsuarioRE(usuarioRE);
                    rolUsuarioRE.setRegistradoPor(usuarioRE.getRegistradoPor());

                    RolRE rolRE;

                    for (String subRol : cadRol) {
                        rolRE = new RolRE();
                        rolRE.setId(subRol);

                        rolUsuarioRE.setRolRE(rolRE);

                        idao.insertar(rolUsuarioRE);

                        flag = rolUsuarioRE.isOk();

                        if (!flag)
                            throw new EdaaException("Error", "No se pudo insertar los roles del usuario.", "500");
                    }

                    usuarioRE.setOk(true);
                }

            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.finishTransaction(flag);
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Actualiza el usuario y contraseña de un objeto UsuarioRE
     *
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public void actualizarUsuarioYContrasena(Object object) throws EdaaException {
        UsuarioDAO usuarioDAO = null;
        try {
            usuarioDAO = new UsuarioDAO();
            usuarioDAO.actualizarUsuarioYContrasena(object);
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (usuarioDAO != null) usuarioDAO.close();
        }
    }

    /**
     * Listo los tipo documentos
     *
     * @return ArrayList
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public Object listarTipoDocumento() throws EdaaException {
        IGeneralDAO idao = null;
        Object list;
        try {
            idao = new TipoDocumentoDAO();
            list = idao.listar();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * lista los cargos existentes
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 Francisco Geraldino Fernandez
     */
    public Object listarCargos() throws EdaaException {
        IGeneralDAO idao = null;
        Object list;
        try {
            idao = new CargoDAO();
            list = idao.listar();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * lista los evaluados por el cargo
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 Francisco Geraldino Fernandez
     */
    public Object listarEvaluadoByCargo(Object objeto) throws EdaaException {
        EvaluadoDAO idao = null;
        Object list;
        try {
            idao = new EvaluadoDAO();
            list = idao.listarByCargo(objeto);
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * lista los evaluados por el año de presentación
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 Francisco Geraldino Fernandez
     */
    public Object listarEvaluadoByAnnioEvaluacion(Object objeto) throws EdaaException {
        EvaluadoDAO idao = null;
        Object list;
        try {
            idao = new EvaluadoDAO();
            list = idao.listarByAnnioPresentacion(objeto);
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }


    /**
     * lista los evaluados por el año de presentación
     *
     * @return ArrayList
     * @throws EdaaException 20-02-2021 Francisco Geraldino Fernandez
     */
    public Object listarEvaluadorByEval(Object objeto) throws EdaaException {
        EvaluadorDAO idao = null;
        Object list;
        try {
            idao = new EvaluadorDAO();
            list = idao.listarByEvaluado(objeto);
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            if (idao != null) idao.close();
        }

        return list;
    }

    /**
     * @param datos
     * @return
     * @throws EdaaException
     */
    public Object generarDatosPdf(DatosPDFVO datos) throws EdaaException {
        FormularioRE formularioRE = null;
        GenerarXMLPDF generarXML = null;
        EvaluadorDAO evaluadorDAO = null;
        EvaluadoDAO evaluadoDAO = null;
        Map caracteristicas = null;
        IDefinitionConnection con = null;
        try {
            con = new DefinitionConnectionEdaa();
            caracteristicas = new TreeMap();
            generarXML = new GenerarXMLPDF();
            formularioRE = datos.getFormulario(); //obtiene los datos del formulario
            StringBuffer pageXML = null;

            //consulta el evaluador
            evaluadorDAO = new EvaluadorDAO(con);
            EvaluadorRE evdr = new EvaluadorRE();
            System.out.println("el id del evaluador " + datos.getIdEvaluador());
            evdr.setId(datos.getIdEvaluador());
            evdr = (EvaluadorRE) evaluadorDAO.buscar2(evdr);

            // consultar evaluado
            evaluadoDAO = new EvaluadoDAO(con);
            EvaluadoRE eval = new EvaluadoRE();
            eval = (EvaluadoRE) evaluadoDAO.buscarEvaluador(evdr);

            //setea datos de evaluador y eveluado
            datos.setEvaluadorRE(evdr);
            datos.setEvaluadoRE(eval);


            for (GrupoValorRE grupoValor : formularioRE.getListaGruposValor()) {
                //consulta las calificaciones de cada grupo de pregunta
                consultarCalificacion((ArrayList<FormularioPreguntaRE>) grupoValor.getListaPreguntas(), datos.getIdEvaluador());

                //organiza las preguntas por caracteristica
                clasificarByCaracteristica((ArrayList<FormularioPreguntaRE>) grupoValor.getListaPreguntas(), caracteristicas);
                //guarda las caracteristicas
                datos.setCaracteristicas(caracteristicas);
                pageXML = (StringBuffer) generarXML.generarXMLGeneral(datos);
            }
            datos.setArchivoB64(generarXML.generarPDFFileByEvaluador(pageXML));
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(con != null){
                try{
                    con.close();
                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        }
        return datos;
    }

    /**
     * @param lista
     * @param caracteristicas
     */
    public void clasificarByCaracteristica(ArrayList<FormularioPreguntaRE> lista, Map caracteristicas) {
        ArrayList aux = null;
        for (FormularioPreguntaRE fopr : lista) {
            if (caracteristicas.containsKey(fopr.getPreguntaRE().getCaracteristicaRE().getNombre())) {
                aux = (ArrayList) caracteristicas.get(fopr.getPreguntaRE().getCaracteristicaRE().getNombre());
                if (aux == null) {
                    aux = new ArrayList();
                    aux.add(fopr);
                } else {
                    aux.add(fopr);
                }
            } else {
                caracteristicas.put(fopr.getPreguntaRE().getCaracteristicaRE().getNombre(), new ArrayList());
                aux = (ArrayList) caracteristicas.get(fopr.getPreguntaRE().getCaracteristicaRE().getNombre());
                aux.add(fopr);

            }
        }
    }

    /**
     * @param lista
     * @param idEvaluador
     * @throws EdaaException 24-02-2021
     */
    public void consultarCalificacion(ArrayList<FormularioPreguntaRE> lista, String idEvaluador) throws EdaaException {
        CalificacionDAO idao = null;
        CalificacionRE calificacion = null;
        IDefinitionConnection con = null;
        Object list;
        try {
            con = new DefinitionConnectionEdaa();
            idao = new CalificacionDAO(con);
            for (FormularioPreguntaRE fopr : lista) {
                calificacion = (CalificacionRE) idao.listarByFormularioPregunta(fopr, idEvaluador);
                if (calificacion == null) {
                    fopr.setCalificacionRE(new CalificacionRE());
                } else {
                    fopr.setCalificacionRE(calificacion);
                }
            }

        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {

            if (idao != null) {
                idao.close();
                if(con != null){
                    try{
                        con.close();
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /**
     * filtra los datos del evaluado por su identificador
     *
     * @return ArrayList
     * @throws EdaaException 23-02-2021 Mario Alejandro Rangel Guerrero
     */
    public Object filtrarEvaluado(Object objeto) throws EdaaException {
        EvaluadoRE evaluadoRE = (EvaluadoRE) objeto;
        IDefinitionConnection connection = null;
        IGeneralDAO dao;
        try {
            connection = new DefinitionConnectionEdaa();
            EvaluadoDAO idao = new EvaluadoDAO(connection);
            evaluadoRE = (EvaluadoRE) idao.buscar(evaluadoRE);

            if (evaluadoRE.isOk()) {
                dao = new PuntajeDAO(connection);
                PuntajeRE puntajeRE = new PuntajeRE();
                puntajeRE.setEvalId(evaluadoRE.getId());
                puntajeRE = (PuntajeRE) dao.buscar(puntajeRE);
                GeneralVO generalVO = null;

                if (null == puntajeRE) {
                    ArrayList<PoblacionVO> list = idao.obtenerDatosGeneralesEvaluado(evaluadoRE.getId());

                    if (list != null) {
                        generalVO = buildPuntajesEvaluado(list);
                    }
                } else {
                    generalVO = new GeneralVO();
                    generalVO.setCantidad_evaluadores(puntajeRE.getCantidadEvaluado());
                    generalVO.setCantidad_participantes(puntajeRE.getCantidadEvaluador());
                    generalVO.setPromedio(String.valueOf(puntajeRE.getPromedio()));
                    generalVO.setPuntajeObtenido(puntajeRE.getPuntaje());
                    generalVO.setOk(true); // bandera para no renderizar botón registrar.
                }

                evaluadoRE.setGeneralVO(generalVO);

                generarPdfEvaluado(evaluadoRE);
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return evaluadoRE;
    }

    private void generarPdfEvaluado(EvaluadoRE evaluadoRE) throws EdaaException {
        try {
            GenerarXMLPDF genPDF = new GenerarXMLPDF();
            StringBuffer pageXML = (StringBuffer) genPDF.generarXMLPuntajeEvaluado(evaluadoRE);
            evaluadoRE.setBase64(genPDF.generarPDFFilePuntajeEvaluado(pageXML));
        } catch (Exception e) {
            logger.fatal(e.getMessage());
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        }
    }

    // 24-02-2021 @: Jesús Sierra

    /**
     * Método que registra el puntaje para un evaluado y cierra o finaliza su proceso de evaluación.
     *
     * @param puntajeRE - Objeto con datos del puntaje y id que asocia al evaluado.
     * @return String con estado del proceso.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public String registrarPuntaje(PuntajeRE puntajeRE) throws EdaaException {
        boolean estado = false;
        EvaluadoRE evaluadoRE;
        EvaluadoDAO evaluadoDAO;
        IGeneralDAO dao;
        IDefinitionConnection conexion = null;
        List<PoblacionVO> listaPuntajes;
        String proceso = "NO_REGISTRADO";

        try {
            conexion = new DefinitionConnectionEdaa();
            conexion.startTransaction();
            evaluadoDAO = new EvaluadoDAO(conexion);
            listaPuntajes = evaluadoDAO.obtenerDatosGeneralesEvaluado(puntajeRE.getEvalId());

            if (null != listaPuntajes) {
                GeneralVO generalVO = buildPuntajesEvaluado(listaPuntajes);
                puntajeRE.setCantidadEvaluado(generalVO.getCantidad_evaluadores());
                puntajeRE.setCantidadEvaluador(generalVO.getCantidad_participantes());
                puntajeRE.setPuntaje(generalVO.getPuntajeObtenido());
                puntajeRE.setPromedio(Double.parseDouble(generalVO.getPromedio()));
                dao = new PuntajeDAO(conexion);
                dao.insertar(puntajeRE);
                estado = puntajeRE.isOk();

                if (estado) {
                    evaluadoRE = new EvaluadoRE();
                    evaluadoRE.setId(puntajeRE.getEvalId());
                    evaluadoRE.setEstado("0");
                    evaluadoRE.setRegistradoPor(puntajeRE.getRegistradoPor());
                    evaluadoDAO.actualizarEstado(evaluadoRE);
                    estado = evaluadoRE.isOk();

                    if (estado) {
                        proceso = "REGISTRADO";
                    }
                }
            } else {
                System.out.println("Evaluado [" + puntajeRE.getEvalId() + "] no encontrado en la entidad edaa.evaluador");
                logger.error("No se ha encontrado datos de evaluadores para el evaluado " + puntajeRE.getEvalId());
            }
        } catch (Exception e) {
            estado = false;
            logger.fatal(e.getMessage());
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try {
                if (null != conexion) {
                    conexion.finishTransaction(estado);
                    conexion.close();
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
                e.printStackTrace();
            }
        }

        return proceso;
    }

    // 24-02-2021 @: Jesús Sierra

    /**
     * Método que construye el objeto de puntajes para un evaluado.
     *
     * @param listaPuntajes - Lista de cantidades agrupadas por población.
     * @return Objeto con puntajes de evaluado.
     */
    private GeneralVO buildPuntajesEvaluado(List<PoblacionVO> listaPuntajes) {
        PoblacionVO evaluadores = listaPuntajes.stream().filter(poblacionVO ->
                "activos".equals(poblacionVO.getPoblacion())
        ).findAny().orElse(new PoblacionVO());
        PoblacionVO participantes = listaPuntajes.stream().filter(poblacionVO ->
                "participantes".equals(poblacionVO.getPoblacion())
        ).findAny().orElse(new PoblacionVO());
        GeneralVO generalVO = new GeneralVO();
        generalVO.setCantidad_evaluadores((short) (evaluadores.getCantidad() + participantes.getCantidad()));
        generalVO.setCantidad_participantes(participantes.getCantidad());
        generalVO.setPuntajeObtenido(participantes.getPuntaje());

        if ( generalVO.getCantidad_participantes() > 0 )
        {
            DecimalFormat decimalFormat = new DecimalFormat("#.##", new DecimalFormatSymbols(Locale.ENGLISH));
            decimalFormat.setRoundingMode( RoundingMode.HALF_UP );
            generalVO.setPromedio(decimalFormat.format(generalVO.getPuntajeObtenido() / generalVO.getCantidad_participantes()));
        }

        return generalVO;
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
