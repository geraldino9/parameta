package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.FormularioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.Procesos;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.DatosPDFVO;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/reportes")
public class ServicioReportes {

    @POST
    @Path("/reporteByEvaluador")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response buscarPersona(DatosPDFVO datosPDF )
    {
        FachadaAdministrador fachadaAdministrador;
        DatosPDFVO dataReturn;
           try
        {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            dataReturn = (DatosPDFVO) fachadaAdministrador.generarDatosPdf( datosPDF );

            if ( null != dataReturn )
                return Response.ok( dataReturn ).build();
            else
                throw new EdaaException( "Sin datos", "Persona no encontrada para el perfil seleccionado.", "503" );
        } catch (EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }
}
