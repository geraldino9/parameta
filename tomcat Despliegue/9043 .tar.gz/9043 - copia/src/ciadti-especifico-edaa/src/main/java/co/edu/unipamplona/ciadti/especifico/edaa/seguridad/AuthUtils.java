package co.edu.unipamplona.ciadti.especifico.edaa.seguridad;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.ReadOnlyJWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import java.text.ParseException;
import java.util.Calendar;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class AuthUtils {
    private static final JWSHeader JWT_HEADER = new JWSHeader(JWSAlgorithm.HS256);
    private static final String TOKEN_SECRET = "jsadsiinwonderland**";
    //public static final String AUTH_HEADER_KEY = "Authorization";

    public static String getSubject(String authHeader) throws ParseException, JOSEException {
        return decodeToken(authHeader).getSubject();
    }

    public static ReadOnlyJWTClaimsSet decodeToken(String authHeader) throws ParseException, JOSEException {
        SignedJWT signedJWT = SignedJWT.parse(getSerializedToken(authHeader));
        if (signedJWT.verify(new MACVerifier(TOKEN_SECRET))) {
            return signedJWT.getJWTClaimsSet();
        } else {
            throw new JOSEException("Verificación de firma fallida");
        }
    }

    public static ReadOnlyJWTClaimsSet decodeToken(String authHeader, boolean esHeader) throws ParseException, JOSEException {
        SignedJWT signedJWT;

        if (esHeader)
            signedJWT = SignedJWT.parse(getSerializedToken(authHeader));
        else
            signedJWT = SignedJWT.parse(authHeader);

        if (signedJWT.verify(new MACVerifier(TOKEN_SECRET))) {
            return signedJWT.getJWTClaimsSet();
        } else {
            throw new JOSEException("Verificación de firma fallida");
        }
    }

    public static Token createToken(String host, UsuarioRE usuarioRE) throws JOSEException {
        Calendar expire;
        JWTClaimsSet claim = new JWTClaimsSet();

        expire = Calendar.getInstance();
        expire.add(Calendar.HOUR, 3);

        claim.setSubject(usuarioRE.getId());
        claim.setIssuer(host);
        claim.setIssueTime(Calendar.getInstance().getTime());
        claim.setExpirationTime(expire.getTime());
        claim.setCustomClaim("documento", usuarioRE.getDocumento());
        claim.setCustomClaim("idTipoDocumento", usuarioRE.getTipoDocumentoRE().getId());
        claim.setCustomClaim("abrvTipoDocumento", usuarioRE.getTipoDocumentoRE().getAbreviatura());

        JWSSigner signer = new MACSigner(TOKEN_SECRET);
        SignedJWT jwt = new SignedJWT(JWT_HEADER, claim);
        jwt.sign(signer);

        return new Token(jwt.serialize());
    }

    private static String getSerializedToken(String authHeader) {
        return authHeader.split(" ")[1];
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
