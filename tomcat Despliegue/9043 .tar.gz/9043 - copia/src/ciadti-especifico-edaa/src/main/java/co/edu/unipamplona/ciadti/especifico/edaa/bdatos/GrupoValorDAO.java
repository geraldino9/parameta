package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.GrupoValorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;

public class GrupoValorDAO implements IGeneralDAO, IPrintException {

    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "grupoValor", "postgresql");

    /**
     GrupoValorDAO     *
     * @throws EdaaException EdaaException
     */
    public GrupoValorDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("GrupoValorDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de GrupoValorDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public GrupoValorDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("GrupoValorDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {

    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {

        ArrayList<GrupoValorRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("grupoValor.listar");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                GrupoValorRE grupoValorRE;
                while (rs.next()) {
                    grupoValorRE = new GrupoValorRE();
                    grupoValorRE.setId(rs.getString("grva_id"));
                    grupoValorRE.setNombre(rs.getString("grva_nombre"));
                    grupoValorRE.setOk(true);
                    list.add(grupoValorRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        GrupoValorRE RE_BUS = (GrupoValorRE) objeto;
        ArrayList<GrupoValorRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("grupoValor.filtrar");
            api.addParameter(new Parameter(RE_BUS.getId(), Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                GrupoValorRE grupoValorRE;
                while (rs.next()) {
                    grupoValorRE = new GrupoValorRE();
                    grupoValorRE.setId(rs.getString("grva_id"));
                    grupoValorRE.setNombre(rs.getString("grva_nombre"));
                    grupoValorRE.setOk(true);
                    list.add(grupoValorRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }
}
