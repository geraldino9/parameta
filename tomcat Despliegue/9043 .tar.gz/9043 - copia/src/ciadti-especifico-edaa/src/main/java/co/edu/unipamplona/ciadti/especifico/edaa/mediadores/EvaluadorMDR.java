package co.edu.unipamplona.ciadti.especifico.edaa.mediadores;

import co.edu.unipamplona.ciadti.especifico.edaa.bdatos.*;
import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.*;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.CalificacionVO;
import co.edu.unipamplona.ciadti.especifico.general.controlador.Log4jInit;
import especifico.interfaces.IDefinitionConnection;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class EvaluadorMDR
{
    private Logger logger;

    public EvaluadorMDR()
    {
        try {
            logger = Log4jInit.logger;
        } catch( Exception e ) {
            System.out.println( "Error en constructor AdministradorMDR() --> " + e.getMessage() );
            e.printStackTrace( System.out );
        }
    }

    // 20-02-2021 @: Jesús Sierra
    /**
     * Método que lista los evaluados correspondientes a un evaluador.
     * @param evaluadorRE - Objeto con el usua_id de usuario evaluador.
     * @return Lista de objetos UsuarioRE con sus listas de evaluaciones.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public List<UsuarioRE> listarEvaluadosByEvaluador( EvaluadorRE evaluadorRE ) throws EdaaException
    {
        IGeneralDAO dao;
        IDefinitionConnection conexion = null;
        List<EvaluadoRE> listaEvaluados;
        List<UsuarioRE> listaPersonas = new ArrayList<>();
        UsuarioRE usuarioRE;

        try
        {
            conexion = new DefinitionConnectionEdaa();
            dao = new EvaluadoDAO( conexion );
            listaEvaluados = (List<EvaluadoRE>) dao.listar( evaluadorRE );

            if ( null != listaEvaluados )
            {
                for ( EvaluadoRE evaluadoRE : listaEvaluados )
                {
                    usuarioRE = listaPersonas.stream()
                            .filter( persona -> evaluadoRE.getUsuarioRE().getId().equals( persona.getId() ) )
                            .findAny()
                            .orElse( null );

                    if ( null == usuarioRE )
                    {
                        usuarioRE = evaluadoRE.getUsuarioRE();
                        usuarioRE.setListaEvaluaciones( new ArrayList<>() );
                        listaPersonas.add( usuarioRE );
                    }

                    evaluadoRE.setUsuarioRE( null );
                    usuarioRE.getListaEvaluaciones().add( evaluadoRE );
                }
            }
        } catch (Exception e) {
            logger.fatal( e.getMessage() );
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try {
                if ( null != conexion ) {
                    conexion.close();
                }
            } catch (Exception e) {
                logger.error( e.getMessage() );
                e.printStackTrace();
            }
        }

        return listaPersonas;
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que organiza las preguntas y opciones de respuestas (grupoValor), para un formulario
     * correspondiente a un usuario evaluado (idEvaluado).
     * @param evaluadoRE - Objeto con el eval_id de usuario a evaluar.
     * @return - Objeto con los datos de la evaluación a realizar.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public FormularioRE formularioByEvaluado( EvaluadoRE evaluadoRE ) throws EdaaException
    {
        FormularioRE formularioRE = null;
        FormularioPreguntaRE formularioPreguntaRE;
        GrupoValorRE grupoValorRE;
        IGeneralDAO dao;
        IDefinitionConnection conexion = null;
        List<FormularioPreguntaRE> list;
        ValorRE valorRE;

        try
        {
            conexion = new DefinitionConnectionEdaa();
            dao = new FormularioPreguntaDAO( conexion );
            list = (List<FormularioPreguntaRE>) dao.listar( evaluadoRE );

            if ( null != list )
            {
                formularioRE = list.get( 0 ).getFormularioRE();
                formularioRE.setListaPreguntas( new ArrayList<>() );
                formularioRE.setListaGruposValor( new ArrayList<>() );

                for ( FormularioPreguntaRE fPreguntaRE : list )
                {
                    // La pregunta no pertenece a ningún grupo de valores.
                    if ( null == fPreguntaRE.getPreguntaRE().getGrupoValorRE() ) {
                        formularioRE.getListaPreguntas().add( fPreguntaRE );
                    }
                    else {
                        grupoValorRE = formularioRE.getListaGruposValor().stream()
                                .filter( grupoValor -> fPreguntaRE.getPreguntaRE().getGrupoValorRE().getId().equals( grupoValor.getId() ) )
                                .findAny()
                                .orElse( null );

                        if ( null == grupoValorRE ) {
                            grupoValorRE = addGrupoValorToFormulario( formularioRE, fPreguntaRE );
                        }

                        formularioPreguntaRE = grupoValorRE.getListaPreguntas().stream()
                                .filter( pregunta -> fPreguntaRE.getPreguntaRE().getId().equals( pregunta.getPreguntaRE().getId() ) )
                                .findAny()
                                .orElse( null );

                        if ( null == formularioPreguntaRE ) {
                            addPreguntaToGrupoValor( grupoValorRE, fPreguntaRE );
                        }

                        valorRE = grupoValorRE.getListaValores().stream()
                                .filter( valor -> fPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().getId().equals( valor.getId() ) )
                                .findAny()
                                .orElse( null );

                        if ( null == valorRE ) {
                            addValorToGrupoValor( grupoValorRE, fPreguntaRE );
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.fatal( e.getMessage() );
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try
            {
                if ( null != conexion ) {
                    conexion.close();
                }
            } catch (Exception e) {
                logger.error( e.getMessage() );
                e.printStackTrace();
            }
        }

        return formularioRE;
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que agrega por referencia un objeto grupo de valores a la lista grupos de valores
     * correspondiente a un objeto formulario.
     * @param formularioRE - Objeto al que se agrega por referencia el grupo de valores a su lista grupos de valores.
     * @param fPreguntaRE - Objeto que contiene los datos del grupo de valor (formularioPregunta[pregunta[grupoValor]]).
     * @return Objeto agregado por referencia a la lista grupos de valores.
     */
    private GrupoValorRE addGrupoValorToFormulario( FormularioRE formularioRE, FormularioPreguntaRE fPreguntaRE )
    {
        GrupoValorRE grupoValorRE = new GrupoValorRE();
        grupoValorRE.setId( fPreguntaRE.getPreguntaRE().getGrupoValorRE().getId() );
        grupoValorRE.setNombre( fPreguntaRE.getPreguntaRE().getGrupoValorRE().getNombre() );
        grupoValorRE.setListaPreguntas( new ArrayList<>() );
        grupoValorRE.setListaValores( new ArrayList<>() );
        formularioRE.getListaGruposValor().add( grupoValorRE );
        return grupoValorRE;
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que agrega por referencia un objeto que contiene los datos de una pregunta, a la lista de preguntas
     * correspondiente a un objeto grupo de valor.
     * @param grupoValorRE - Objeto al que se agrega por referencia una pregunta a su lista de preguntas.
     * @param fPreguntaRE - Objeto que contiene los datos de la pregunta (incluyendo su característica).
     */
    private void addPreguntaToGrupoValor( GrupoValorRE grupoValorRE, FormularioPreguntaRE fPreguntaRE )
    {
        FormularioPreguntaRE formularioPreguntaRE = new FormularioPreguntaRE();
        formularioPreguntaRE.setId( fPreguntaRE.getId() );
        formularioPreguntaRE.setOrden( fPreguntaRE.getOrden() );
        formularioPreguntaRE.setPreguntaRE( new PreguntaRE() );
        formularioPreguntaRE.getPreguntaRE().setId( fPreguntaRE.getPreguntaRE().getId() );
        formularioPreguntaRE.getPreguntaRE().setContenido( fPreguntaRE.getPreguntaRE().getContenido() );
        formularioPreguntaRE.getPreguntaRE().setCaracteristicaRE( fPreguntaRE.getPreguntaRE().getCaracteristicaRE() );
        grupoValorRE.getListaPreguntas().add( formularioPreguntaRE );
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que agrega por referencia un objeto que contiene los datos de un valor de respuesta, a la lista de
     * valores correspondiente a un objeto grupo de valor.
     * @param grupoValorRE - Objeto al que se agrega por referencia un valor a su lista de valores.
     * @param fPreguntaRE - Objeto que contiene los datos de un valor de respuesta para las preguntas que pertenecen
     *                    a su objeto grupo de valor (formularioPregunta[pregunta[grupoValor[valor]]]).
     */
    private void addValorToGrupoValor( GrupoValorRE grupoValorRE, FormularioPreguntaRE fPreguntaRE )
    {
        ValorRE valorRE = new ValorRE();
        valorRE.setId( fPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().getId() );
        valorRE.setDescripcion( fPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().getDescripcion() );
        valorRE.setPuntaje( fPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().getPuntaje() );
        valorRE.setAbreviatura( fPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().getAbreviatura() );
        grupoValorRE.getListaValores().add( valorRE );
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que procesa y registra la calificación correspondiente a una evaluación.
     * @param calificacionVO - Objeto con datos de la calificación.
     * @return String con estado del proceso.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public String registrarCalificacion( CalificacionVO calificacionVO ) throws EdaaException
    {
        boolean estado = false;
        CalificacionRE calificacionRE;
        double acumulado = 0d;
        Double puntaje;
        EvaluadorRE evaluadorRE = new EvaluadorRE();
        IGeneralDAO dao, daoAux;
        IDefinitionConnection conexion = null;
        Map<String, Double> mapPuntajes = new HashMap<>();
        short c = 0;
        String proceso = "NO_REGISTRADO";
        ValorRE valorRE;

        try
        {
            conexion = new DefinitionConnectionEdaa();
            conexion.startTransaction();
            dao = new EvaluadorDAO( conexion );
            evaluadorRE.setUsuaId( calificacionVO.getIdUsuario() );
            evaluadorRE.setEvalId( calificacionVO.getIdEvaluado() );
            evaluadorRE = (EvaluadorRE) dao.buscar( evaluadorRE );

            if ( null == evaluadorRE ) {
                throw new Exception( "[" + calificacionVO.getIdEvaluado() + "] No se ha encontrado los datos del evaluador para el usuario: " + calificacionVO.getIdUsuario() );
            }

            dao = new CalificacionDAO( conexion );
            daoAux = new ValorDAO( conexion );

            for ( CalificacionVO.Respuesta respuesta : calificacionVO.getRespuestas() )
            {
                calificacionRE = new CalificacionRE();
                calificacionRE.setEvalId( calificacionVO.getIdEvaluado() );
                calificacionRE.setEvdrId( evaluadorRE.getId() );
                calificacionRE.setFoprId( respuesta.getIdFormPregunta() );
                calificacionRE.setRegistradoPor( calificacionVO.getRegistradoPor() );

                if ( null != respuesta.getIdValor() ) {
                    calificacionRE.setValoId( respuesta.getIdValor() );
                    // Proceso calificación v1.0
                    puntaje = mapPuntajes.get( respuesta.getIdValor() );

                    if ( null == puntaje )
                    {
                        valorRE = new ValorRE();
                        valorRE.setId( respuesta.getIdValor() );
                        valorRE = (ValorRE) daoAux.buscar( valorRE );
                        puntaje = valorRE.getPuntaje();
                        mapPuntajes.put( respuesta.getIdValor(), puntaje );
                    }

                    acumulado += puntaje;
                    c++;
                    // Fin proceso calificación v1.0
                }
                else {
                    calificacionRE.setRespuesta( respuesta.getValor() );
                }

                dao.insertar( calificacionRE );
                estado = calificacionRE.isOk();

                if ( !estado ) {
                    break;
                }
            }

            if ( estado )
            {
                evaluadorRE.setObservacion( calificacionVO.getObservacion() );
                evaluadorRE.setPromedio( acumulado / c ); // resultado de calificación.
                evaluadorRE.setEstado( "0" );
                evaluadorRE.setRegistradoPor( calificacionVO.getRegistradoPor() );
                dao = new EvaluadorDAO( conexion );
                dao.actualizar( evaluadorRE );
                estado = evaluadorRE.isOk();

                if ( estado ) {
                    proceso = "REGISTRADO";
                }
            }
        } catch (Exception e) {
            estado = false;
            logger.fatal( e.getMessage() );
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "", "", e.getMessage());
        } finally {
            try
            {
                if ( null != conexion ) {
                    conexion.finishTransaction( estado );
                    conexion.close();
                }
            } catch (Exception e) {
                logger.error( e.getMessage() );
                e.printStackTrace();
            }
        }

        return proceso;
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
