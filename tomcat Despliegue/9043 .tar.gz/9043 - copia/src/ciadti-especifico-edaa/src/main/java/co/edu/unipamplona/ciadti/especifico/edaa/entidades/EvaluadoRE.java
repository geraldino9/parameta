package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.GeneralVO;

import java.sql.Timestamp;

public class EvaluadoRE {
    private String id;
    private Timestamp fechaInicio;
    private String usuaId;
    private String cargId;
    private String annioEvaluacion;
    private String tiempo;
    private Timestamp fechaPosesion;
    private String acta;
    private String vigencia;
    private Timestamp fechaFin;
    private String registradoPor;
    private String fechaRegistro;
    private boolean ok;
    private String fechaPosesionStr;
    private String fechaInicioStr;
    private String fechaFinStr;
    private String estado;
    private UsuarioRE usuarioRE;
    private CargoRE cargoRE;
    private GeneralVO generalVO;
    private String base64;


    public EvaluadoRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Timestamp getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Timestamp fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getUsuaId() {
        return usuaId;
    }

    public void setUsuaId(String usuaId) {
        this.usuaId = usuaId;
    }

    public String getCargId() {
        return cargId;
    }

    public void setCargId(String cargId) {
        this.cargId = cargId;
    }

    public String getAnnioEvaluacion() {
        return annioEvaluacion;
    }

    public void setAnnioEvaluacion(String annioEvaluacion) {
        this.annioEvaluacion = annioEvaluacion;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    public Timestamp getFechaPosesion() {
        return fechaPosesion;
    }

    public void setFechaPosesion(Timestamp fechaPosesion) {
        this.fechaPosesion = fechaPosesion;
    }

    public String getActa() {
        return acta;
    }

    public void setActa(String acta) {
        this.acta = acta;
    }

    public String getVigencia() {
        return vigencia;
    }

    public void setVigencia(String vigencia) {
        this.vigencia = vigencia;
    }

    public Timestamp getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Timestamp fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public String getFechaPosesionStr() {
        return fechaPosesionStr;
    }

    public void setFechaPosesionStr(String fechaPosesionStr) {
        this.fechaPosesionStr = fechaPosesionStr;
    }

    public String getFechaInicioStr() {
        return fechaInicioStr;
    }

    public void setFechaInicioStr(String fechaInicioStr) {
        this.fechaInicioStr = fechaInicioStr;
    }

    public String getFechaFinStr() {
        return fechaFinStr;
    }

    public void setFechaFinStr(String fechaFinStr) {
        this.fechaFinStr = fechaFinStr;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public UsuarioRE getUsuarioRE() {
        return usuarioRE;
    }

    public void setUsuarioRE(UsuarioRE usuarioRE) {
        this.usuarioRE = usuarioRE;
    }

    public CargoRE getCargoRE() {
        return cargoRE;
    }

    public void setCargoRE(CargoRE cargoRE) {
        this.cargoRE = cargoRE;
    }

    public GeneralVO getGeneralVO() {
        return generalVO;
    }

    public void setGeneralVO(GeneralVO generalVO) {
        this.generalVO = generalVO;
    }

    public String getBase64() {
        return base64;
    }

    public void setBase64(String base64) {
        this.base64 = base64;
    }
}
