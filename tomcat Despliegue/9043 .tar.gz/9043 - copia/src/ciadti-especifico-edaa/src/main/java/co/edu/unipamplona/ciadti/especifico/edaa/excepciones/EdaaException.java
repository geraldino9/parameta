package co.edu.unipamplona.ciadti.especifico.edaa.excepciones;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class EdaaException extends java.lang.Exception {
    private String tipo = "EdaaException";
    private String clase = "";
    private String proceso = "";
    private int estado;
    private String status;

    public EdaaException() {
    }

    public EdaaException(String msg) {
        super(msg);
    }

    public EdaaException(String msg, int estado) {
        super(msg);
        this.estado = estado;
    }

    public EdaaException(String tipo, String msg) {
        super(msg);
        this.tipo = tipo;
    }

    public EdaaException(String tipo, String msg, String status) {
        super(msg);
        this.tipo = tipo;
        this.status = status;
    }

    public EdaaException(String tipo, String clase, String metodo, String msg) {
        super(msg);
        this.tipo = tipo;
        this.clase = clase;
        this.proceso = metodo;
    }


    public EdaaException(String tipo, String clase, String metodo, String msg, Object exception) {
        super(msg);
        this.tipo = tipo;
        this.clase = clase;
        this.proceso = metodo;
        //NotificarException.notificar(tipo, clase, metodo, msg,exception);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }

    public String getProceso() {
        return proceso;
    }

    public void setProceso(String proceso) {
        this.proceso = proceso;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
