package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadoRE;

import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;
import com.google.gson.Gson;
import javax.annotation.security.PermitAll;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.FormularioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.Procesos;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Path("/evaluados")
public class ServicioEvaluado
{
    @GET
    @Path("/{idUsuario}")
    // @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    public Response listar( @PathParam("idUsuario") Long idUsuario )
    {
        try
        {
            if ( null == idUsuario ) {
                throw new EdaaException( "Dato requerido", "Falta el id de usuario." );
            }

            EvaluadorRE evaluadorRE = new EvaluadorRE();
            evaluadorRE.setUsuaId( idUsuario.toString() );
            FachadaAdministrador fachadaAdministrador = FachadaAdministrador.getInstancia();
            List<UsuarioRE> listaEvaluados = fachadaAdministrador.listarEvaluadosByEvaluador( evaluadorRE );
            return Response.ok( listaEvaluados ).build();
        } catch (EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }

    @GET
    @Path("/formulario/{idEvaluado}")
    // @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    public Response consultarFormularioByEvaluado( @PathParam("idEvaluado") Long idEvaluado )
    {
        try
        {
            if ( null == idEvaluado ) {
                throw new EdaaException( "Dato requerido", "Falta el id de evaluado." );
            }

            EvaluadoRE evaluadoRE = new EvaluadoRE();
            evaluadoRE.setId( idEvaluado.toString() );
            FachadaAdministrador fachadaAdministrador = FachadaAdministrador.getInstancia();
            FormularioRE formularioRE = fachadaAdministrador.formularioByEvaluado( evaluadoRE );
            return Response.ok( Objects.requireNonNullElseGet( formularioRE, Object::new ) ).build();
        } catch (EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }


    @GET
    @Path("/filtByannio/{annio}")
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarEvaluadoByAnnioEvaluacion(@PathParam("annio") String annio) {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            EvaluadoRE evaluadoRE = new EvaluadoRE();
            evaluadoRE.setAnnioEvaluacion(annio);
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            Object list = fachadaAdministrador.listarEvaluadoByAnnioEvaluacion(evaluadoRE);

            if (list != null) {
                return Response.ok(list).build();
            }

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("FILTRAR evaluadores por año");
            respuestaVO.setMensaje("no hay datos");

            return Response.ok(gson.toJson(respuestaVO)).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }


    @GET
    @Path("/filtByCargo/{cargoId}")
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarEvaluadoByCargo(@PathParam("cargoId") String cargoId) {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            EvaluadoRE evaluadoRE = new EvaluadoRE();
            evaluadoRE.setCargId(cargoId);
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            Object list = fachadaAdministrador.listarEvaluadoByCargo(evaluadoRE);

            if (list != null) {
                return Response.ok(list).build();
            }

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("FILTRAR ROLES POR USUARIO");
            respuestaVO.setMensaje("EL USUARIO NO TIENE ROLES ASOCIADOS");

            return Response.ok(gson.toJson(respuestaVO)).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @Path("/filtByIdEval/{id}")
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response filtrarEvaluado(@PathParam("id") String id) {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            EvaluadoRE evaluadoRE = new EvaluadoRE();
            evaluadoRE.setId(id);

            fachadaAdministrador = FachadaAdministrador.getInstancia();
            evaluadoRE = (EvaluadoRE) fachadaAdministrador.filtrarEvaluado(evaluadoRE);

            if (evaluadoRE.isOk()) {
                return Response.ok(evaluadoRE).build();
            }

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("Filtrar evaluador por identificador");
            respuestaVO.setMensaje("No existe el evaluador");

            return Response.ok(gson.toJson(respuestaVO)).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }
}
/*
 *  20/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */

