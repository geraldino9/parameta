package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

public class FormularioCargoRE {
    private String id;
    private String cargoId;
    private String formId;
    private String estado;
    private String RegistradoPor;
    private String fechaRegistro;
    private boolean ok;

    public FormularioCargoRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCargoId() {
        return cargoId;
    }

    public void setCargoId(String cargoId) {
        this.cargoId = cargoId;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getRegistradoPor() {
        return RegistradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        RegistradoPor = registradoPor;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }
}
