package co.edu.unipamplona.ciadti.especifico.edaa.valueobject;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class ErrorVO
{
    private String status;
    private String mensaje;
    private String tipo;
    private String titulo;
    private String servicio;
    private int estado;
    private String proceso;

    public ErrorVO() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public String getProceso() {
        return proceso;
    }

    public void setProceso(String proceso) {
        this.proceso = proceso;
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
