package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import java.sql.Timestamp;

public class TipoDocumentoRE {
    private String id;
    private String nombre;
    private String abreviatura;
    private String registradoPor;
    private Timestamp fechaCambio;
    private boolean ok;

    public TipoDocumentoRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAbreviatura() {
        return abreviatura;
    }

    public void setAbreviatura(String abreviatura) {
        this.abreviatura = abreviatura;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public Timestamp getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Timestamp fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }
}

/*
 *  18/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : CREACIÓN
 *
 */