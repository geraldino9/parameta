package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.CalificacionRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.PuntajeRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.ValorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class PuntajeDAO implements IGeneralDAO, IPrintException {
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "puntaje", "postgresql");

    /**
     * Crea una nueva instancia de PuntajeDAO
     *
     * @throws EdaaException EdaaException
     */
    public PuntajeDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("PuntajeDAO()", e);
            throw new EdaaException(e.getClass().getName(), "PuntajeDAO", "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de PuntajeDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public PuntajeDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("PuntajeDAO(Object conexion)", e);
            throw new EdaaException(e.getClass().getName(), "PuntajeDAO", "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    /**
     * Método que almacena en la base de datos un registro correspondiente a la entidad EDAA.PUNTAJE
     *
     * @param objeto - Datos del puntaje.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public void insertar(Object objeto) throws EdaaException {
        PuntajeRE puntajeRE = (PuntajeRE) objeto;
        String res;
        boolean insertado;

        try {
            if (null != puntajeRE) {
                api.clear();
                api.addStrSql("puntaje.insertarProcedure");
                api.addParameter(new Parameter(puntajeRE.getEvalId(), Types.NUMERIC));
                api.addParameter(new Parameter(puntajeRE.getCantidadEvaluador(), Types.NUMERIC));
                api.addParameter(new Parameter(puntajeRE.getPuntaje(), Types.NUMERIC));
                api.addParameter(new Parameter(puntajeRE.getPromedio(), Types.NUMERIC));
                api.addParameter(new Parameter(puntajeRE.getCantidadEvaluado(), Types.NUMERIC));
                api.addParameter(new Parameter(puntajeRE.getRegistradoPor(), Types.VARCHAR));
                res = (String) api.executeProcedure(true);
                insertado = res != null && !res.equals("-1") && !res.equals("0");

                if (insertado) {
                    puntajeRE.setId(res);
                }

                puntajeRE.setOk(insertado);
            }
        } catch (SQLException e) {
            puntajeRE.setOk(false);
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "PuntajeDAO", "SQL insertar( Object )", e.getMessage());
        } catch (Exception e) {
            puntajeRE.setOk(false);
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "PuntajeDAO", "insertar( Object )", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object listar() throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Método que busca un puntaje para un evaluado.
     *
     * @param objeto - PuntajeRE con id de evaluado.
     * @return Objeto con datos de puntaje.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public Object buscar(Object objeto) throws EdaaException {
        PuntajeRE puntajeRE_Bus = (PuntajeRE) objeto;
        PuntajeRE puntajeRE = null;
        ResultSet rs = null;

        try {
            if (null == puntajeRE_Bus) {
                return null;
            }

            api.clear();
            api.addStrSql("puntaje.buscar");
            api.addParameter(new Parameter(puntajeRE_Bus.getEvalId(), Types.NUMERIC));
            rs = (ResultSet) api.executeQuery();

            if (rs.next()) {
                puntajeRE = new PuntajeRE();
                puntajeRE.setId(rs.getString("punt_id"));
                puntajeRE.setEvalId(rs.getString("eval_id"));
                puntajeRE.setCantidadEvaluador(rs.getShort("punt_cantidadevaluador"));
                puntajeRE.setPuntaje(rs.getDouble("punt_puntaje"));
                puntajeRE.setPromedio(rs.getDouble("punt_promedio"));
                puntajeRE.setCantidadEvaluado(rs.getShort("punt_cantidadevaluado"));
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "ValorDAO", "SQL buscar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "ValorDAO", "buscar( Object )", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return puntajeRE;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error ::> co.edu.unipamplona.ciadti.edaa.bdatos ::> clase PuntajeDAO ::> function public void close() ::> Exception ::>" + e.getMessage());
        }
    }
}
/*
 *  24/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
