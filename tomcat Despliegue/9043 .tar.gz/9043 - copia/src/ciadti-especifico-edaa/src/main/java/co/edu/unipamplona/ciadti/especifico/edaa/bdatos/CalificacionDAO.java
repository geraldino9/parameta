package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.CalificacionRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.FormularioPreguntaRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolUsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class CalificacionDAO implements IGeneralDAO, IPrintException {
    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "calificacion", "postgresql");

    /**
     * Crea una nueva instancia de CalificacionDAO
     *
     * @throws EdaaException EdaaException
     */
    public CalificacionDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("CalificacionDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de CalificacionDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public CalificacionDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("CalificacionDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que almacena en la base de datos un registro correspondiente a la entidad EDAA.CALIFICACION
     * @param objeto - Datos de la calificación.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public void insertar( Object objeto ) throws EdaaException
    {
        CalificacionRE calificacionRE = (CalificacionRE) objeto;
        String res;
        boolean insertado;

        try
        {
            if ( null != calificacionRE )
            {
                api.clear();
                api.addStrSql( "calificacion.insertarProcedure" );
                api.addParameter(new Parameter(calificacionRE.getEvalId(), Types.NUMERIC));
                api.addParameter(new Parameter(calificacionRE.getEvdrId(), Types.NUMERIC));
                api.addParameter(new Parameter(calificacionRE.getFoprId(), Types.NUMERIC));
                api.addParameter(new Parameter(calificacionRE.getValoId(), Types.NUMERIC));
                api.addParameter(new Parameter(calificacionRE.getRegistradoPor(), Types.VARCHAR));
                res = (String) api.executeProcedure( true );
                insertado = res != null && !res.equals("-1") && !res.equals("0");

                if ( insertado ) {
                    calificacionRE.setId( res );
                }

                calificacionRE.setOk( insertado );
            }
        } catch (SQLException e) {
            calificacionRE.setOk(false);
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "CalificacionDAO", "SQL insertar( Object )", e.getMessage());
        } catch (Exception e) {
            calificacionRE.setOk(false);
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "CalificacionDAO", "insertar( Object )", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {

    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {
        ArrayList<CalificacionRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("calificacion.listar");
            rs = (ResultSet) api.executeQuery();
            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                CalificacionRE calificacionRE;
                while (rs.next()) {
                    calificacionRE = new CalificacionRE();
                    calificacionRE.setId(rs.getString("cali_id"));
                    calificacionRE.setEvalId(rs.getString("eval_id"));
                    calificacionRE.setEvdrId(rs.getString("evdr_id"));
                    calificacionRE.setFoprId(rs.getString("fopr_id"));
                    calificacionRE.setValoId(rs.getString("valo_id"));
                    calificacionRE.setOk(true);
                    list.add(calificacionRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        CalificacionRE calificacionRE_BUS = (CalificacionRE) objeto;
        ArrayList<CalificacionRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("calificacion.filtrar");
            api.addParameter(new Parameter(calificacionRE_BUS.getId(), Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                CalificacionRE calificacionRE;
                while (rs.next()) {
                    calificacionRE = new CalificacionRE();
                    calificacionRE.setId(rs.getString("cali_id"));
                    calificacionRE.setEvalId(rs.getString("eval_id"));
                    calificacionRE.setEvdrId(rs.getString("evdr_id"));
                    calificacionRE.setFoprId(rs.getString("fopr_id"));
                    calificacionRE.setValoId(rs.getString("valo_id"));
                    calificacionRE.setOk(true);
                    list.add(calificacionRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }

    public Object listarByFormularioPregunta(Object objeto, String idEvaluador) throws EdaaException {
        FormularioPreguntaRE RE_BUS = (FormularioPreguntaRE) objeto;
        CalificacionRE calificacionRE = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("calificacion.filtrarByFoprAndEvaluador");
            api.addParameter(new Parameter(RE_BUS.getId(), Types.NUMERIC));
            api.addParameter(new Parameter(idEvaluador, Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                calificacionRE = new CalificacionRE();
                if (rs.next()) {
                    calificacionRE.setId(rs.getString("cali_id"));
                    calificacionRE.setEvalId(rs.getString("eval_id"));
                    calificacionRE.setEvdrId(rs.getString("evdr_id"));
                    calificacionRE.setFoprId(rs.getString("fopr_id"));
                    calificacionRE.setValoId(rs.getString("valo_id"));
                    calificacionRE.setOk(true);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return calificacionRE;
    }
}
