package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolUsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class RolDAO implements IGeneralDAO, IPrintException {
    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "rol", "postgresql");

    /**
     * Crea una nueva instancia de RolDAO
     *
     * @throws EdaaException EdaaException
     */
    public RolDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("RolDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de RolDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public RolDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("RolDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    /**
     * Método que inserta un registro a la entidad: EDAA.ROL
     *
     * @param objeto de tipo RolRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    /**
     * Método que actualiza un registro de la entidad: EDAA.ROL
     *
     * @param objeto de tipo RolRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void actualizar(Object objeto) throws EdaaException {
    }

    /**
     * Método que elimina un registro de la entidad: EDAA.ROL
     *
     * @param objeto de tipo UsuarioRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {
        ArrayList<RolRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("rol.listar");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                RolRE rolRE;
                while (rs.next()) {
                    rolRE = new RolRE();
                    rolRE.setId(rs.getString("rol_id"));
                    rolRE.setNombre(rs.getString("rol_nombre"));
                    rolRE.setOk(true);

                    list.add(rolRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    /**
     * Método que consulta los registros correspondientes a la entidad: EDAA.ROL
     *
     * @return lista de objetos UsuarioRE
     * @throws EdaaException EdaaException
     */
    @Override
    public Object listar(Object objeto) throws EdaaException {
        RolUsuarioRE rolUsuarioRE = (RolUsuarioRE) objeto;
        ArrayList<RolRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("rol.filtrar");
            api.addParameter(new Parameter(rolUsuarioRE.getUsuarioRE().getId(), Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                RolRE rolRE;
                while (rs.next()) {
                    rolRE = new RolRE();
                    rolRE.setId(rs.getString("rol_id"));
                    rolRE.setNombre(rs.getString("rol_nombre"));
                    rolRE.setOk(true);

                    list.add(rolRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }
}

/*
 *  19/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : CREACIÓN
 *
 */