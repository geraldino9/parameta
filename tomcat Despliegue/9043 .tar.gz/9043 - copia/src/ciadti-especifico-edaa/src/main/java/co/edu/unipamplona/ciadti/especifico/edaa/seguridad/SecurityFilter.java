package co.edu.unipamplona.ciadti.especifico.edaa.seguridad;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.JWTClaimsSet;

import javax.annotation.Priority;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.security.Principal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;

import static co.edu.unipamplona.ciadti.especifico.edaa.seguridad.AuthUtils.*;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class SecurityFilter implements ContainerRequestFilter, ContainerResponseFilter {
    private static final String EXPIRE_ERROR_MSG = "Token ha expirado",
            JWT_ERROR_MSG = "No se puede analizar JWT",
            JWT_INVALID_MSG = "Token JWT no válido";

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        /*Authorizer authorizer;
        boolean rolEncontrado;
        RolVortalVO rolVortalVO;
        SecurityContext originalContext = requestContext.getSecurityContext();
        String authHeader = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);

        if ( authHeader == null || authHeader.isEmpty() || authHeader.split(" ").length != 2 )
        {
            authorizer = new Authorizer( new ArrayList(), "", originalContext.isSecure() );
            requestContext.setSecurityContext( authorizer );
        }
        else {
            JWTClaimsSet claimSet;
            try {
                claimSet = (JWTClaimsSet) decodeToken(authHeader);
            } catch (ParseException e) {
                throw new IOException(JWT_ERROR_MSG);
            } catch (JOSEException e) {
                throw new IOException(JWT_INVALID_MSG);
            }

            if ( Calendar.getInstance().getTime().after( claimSet.getExpirationTime() ) ){
                System.out.println( "Token expirado." );
                throw new NotAuthorizedException(EXPIRE_ERROR_MSG);
            }
            else {
                try {
                    FachadaAdministrador fachadaAdministrador = FachadaAdministrador.getInstancia();
                    ArrayList<RolVortalVO> listaRoles = fachadaAdministrador.listarRolesVortalUP( null );

                    if ( null == listaRoles || listaRoles.isEmpty() )
                        throw new NotAuthorizedException( "No se encontraron roles asociados en el vortal." );
                    else {
                        rolVortalVO = listaRoles.stream()
                                .filter( rol -> claimSet.getCustomClaim( "idRol" ).equals( rol.getId() ) )
                                .findAny().orElse( null );
                        rolEncontrado = null != rolVortalVO;

                        if ( !rolEncontrado )
                        {
                            listaRoles = fachadaAdministrador.listarRolesVortalUP( "RENOVAR_LISTA" );

                            if ( null == listaRoles || listaRoles.isEmpty() )
                                throw new NotAuthorizedException( "No se encontraron roles asociados en el vortal." );
                        }
                    }*/
                    /*
                    UsuarioRE usuario = new  UsuarioRE();
                    usuario.setId( claimSet.getSubject() ); // cuando se creó el token, seteó el idUsuario que es el mismo con el que se hará la consulta a la bd.
                    usuario.setListaRoles( listaRoles );*/

                    /*authorizer = new Authorizer( listaRoles, claimSet.getSubject(), originalContext.isSecure() );
                    requestContext.setSecurityContext(authorizer);
                } catch ( Exception ex ) {
                    ex.printStackTrace( System.out );
                    throw new IOException(ex.getMessage());
                }
            }
        }*/
    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext response) {
        response.getHeaders().putSingle("Access-Control-Allow-Origin", "*");
        response.getHeaders().putSingle("Access-Control-Allow-Methods", "OPTIONS, GET, POST, PUT, DELETE");
        response.getHeaders().putSingle("Access-Control-Allow-Headers", "Content-Type, Authorization, public-key-pins");
    }

    /*public static class Authorizer implements SecurityContext {

        List<RolVortalVO> roles;
        String username;
        boolean isSecure;

        public Authorizer(List<RolVortalVO> roles, String username, boolean isSecure) {
            this.roles = roles;
            this.username = username;
            this.isSecure = isSecure;
        }

        @Override
        public Principal getUserPrincipal() {
            return new User(username);
        }

        @Override
        public boolean isUserInRole( String rol )
        {
            //return rol.equals(role); Uno a muchos
            boolean contiene = roles.contains(new RolVortalVO(rol));

            return contiene;
        }

        @Override
        public boolean isSecure() {
            return isSecure;
        }

        @Override
        public String getAuthenticationScheme() {
            return "JWT Authentication";
        }
    }*/

    public static class User implements Principal {

        String name;

        public User(String name) {
            this.name = name;
        }

        @Override
        public String getName() {
            return name;
        }
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
