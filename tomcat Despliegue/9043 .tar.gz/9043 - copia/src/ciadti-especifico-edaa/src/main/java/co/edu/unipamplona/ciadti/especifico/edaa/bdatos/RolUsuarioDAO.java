package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolUsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.TipoDocumentoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import co.edu.unipamplona.ciadti.especifico.utilidades.Encriptacion;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class RolUsuarioDAO implements IGeneralDAO, IPrintException {
    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "rolUsuario", "postgresql");

    /**
     * Crea una nueva instancia de RolUsuarioDAO
     *
     * @throws EdaaException EdaaException
     */
    public RolUsuarioDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("RolUsuarioDAO()", e);
            throw new EdaaException(e.getClass().getName(), "RolUsuarioDAO", "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de UsuarioDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public RolUsuarioDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("RolUsuarioDAO(Object conexion)", e);
            throw new EdaaException(e.getClass().getName(), "RolUsuarioDAO", "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    /**
     * Método que inserta un registro a la entidad: EDAA.USUARIO
     *
     * @param objeto de tipo UsuarioRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void insertar(Object objeto) throws EdaaException {
        RolUsuarioRE rolUsuarioRE = (RolUsuarioRE) objeto;
        String res;

        try {
            if (null != rolUsuarioRE) {
                api.clear();
                api.addStrSql("rolUsuario.insertarProcedure");
                api.addParameter(new Parameter(rolUsuarioRE.getUsuarioRE().getId(), Types.NUMERIC));
                api.addParameter(new Parameter(rolUsuarioRE.getRolRE().getId(), Types.NUMERIC));
                api.addParameter(new Parameter(rolUsuarioRE.getRegistradoPor(), Types.VARCHAR));
                res = (String) api.executeProcedure(true);

                if (res != null && !res.equals("-1") && !res.equals("0"))
                    rolUsuarioRE.setOk(true);
            }
        } catch (Exception e) {
            printException("insertar(Object objeto)", e);
            throw new EdaaException(e.getClass().getName(), "RolUsuarioDAO", "insertar( Object )", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {
    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {
        RolUsuarioRE rolUsuarioRE = (RolUsuarioRE) objeto;
        try {
            if (null != rolUsuarioRE) {
                api.clear();
                api.addStrSql("rolUsuario.eliminar");
                api.addParameter(new Parameter(rolUsuarioRE.getUsuarioRE().getId(), Types.NUMERIC));
                rolUsuarioRE.setOk(api.executeUpdate() >= 0);
            }
        } catch (Exception e) {
            printException("eliminar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "eliminar(Object objeto)", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public Object listar() throws EdaaException {
        return null;
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }
}
/*
 *  21/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : CREACIÓN
 *
 */
