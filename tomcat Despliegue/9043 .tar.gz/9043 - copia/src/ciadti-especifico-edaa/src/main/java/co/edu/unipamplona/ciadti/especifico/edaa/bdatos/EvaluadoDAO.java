package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.*;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.ConvertirFecha;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.GeneralVO;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.PoblacionVO;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class EvaluadoDAO implements IGeneralDAO, IPrintException {

    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "evaluado", "postgresql");

    /**
     * EvaluadoDAO     *
     *
     * @throws EdaaException EdaaException
     */
    public EvaluadoDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("EvalueadoDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de EvalueadoDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public EvaluadoDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("EvalueadoDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {

    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {

        ArrayList<EvaluadoRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluado.listarTodo");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EvaluadoRE evaluadorRE;
                while (rs.next()) {
                    evaluadorRE = new EvaluadoRE();
                    evaluadorRE.setId(rs.getString("eval_id"));
                    evaluadorRE.setFechaInicio(rs.getTimestamp("eval_fechainicio"));
                    evaluadorRE.setUsuaId(rs.getString("usua_id"));
                    evaluadorRE.setCargId(rs.getString("carg_id"));
                    evaluadorRE.setAnnioEvaluacion(rs.getString("eval_anoevaluacion"));
                    evaluadorRE.setTiempo(rs.getString("eval_tiempo"));
                    evaluadorRE.setFechaPosesion(rs.getTimestamp("eval_fechaposesion"));
                    evaluadorRE.setActa(rs.getString("eval_acta"));
                    evaluadorRE.setVigencia(rs.getString("eval_vegencia"));
                    evaluadorRE.setFechaFin(rs.getTimestamp("eval_fechafin"));
                    evaluadorRE.setOk(true);
                    list.add(evaluadorRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    // 20-02-2021 @: Jesús Sierra
    /**
     * Método que consulta los evaluados para un evaluador
     *
     * @param objeto - EvaluadoRE con el usua_id de usuario evaluador.
     * @return Lista de objetos EvaluadoRE.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public Object listar(Object objeto) throws EdaaException {
        List<EvaluadoRE> list = null;
        EvaluadoRE evaluadoRE;
        EvaluadorRE evaluadorRE_BUS = (EvaluadorRE) objeto;
        ResultSet rs = null;

        try {
            api.clear();
            api.addStrSql("evaluado.listar");
            api.addParameter(new Parameter(evaluadorRE_BUS.getUsuaId(), Types.NUMERIC));
            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();

                while (rs.next()) {
                    evaluadoRE = new EvaluadoRE();
                    // Datos personales de evaluado.
                    evaluadoRE.setUsuarioRE( new UsuarioRE() );
                    evaluadoRE.getUsuarioRE().setId( rs.getString( "usua_id" ) );
                    evaluadoRE.getUsuarioRE().setDocumento( rs.getString( "usua_documento" ) );
                    evaluadoRE.getUsuarioRE().setPrimerNombre( rs.getString( "usua_primernombre" ) );
                    evaluadoRE.getUsuarioRE().setSegundoNombre( rs.getString( "usua_segundonombre" ) );
                    evaluadoRE.getUsuarioRE().setPrimerApellido( rs.getString( "usua_primerapellido" ) );
                    evaluadoRE.getUsuarioRE().setSegundoApellido( rs.getString( "usua_segundoapellido" ) );
                    evaluadoRE.getUsuarioRE().setNombreCompleto( rs.getString( "nombre_completo" ) );
                    evaluadoRE.getUsuarioRE().setTipoDocumentoRE( new TipoDocumentoRE() );
                    evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setId( rs.getString( "tido_id" ) );
                    evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setAbreviatura( rs.getString( "tido_abreviatura" ) );
                    evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setNombre( rs.getString( "tido_nombre" ) );

                    // Cargo de evaluado.
                    evaluadoRE.setCargoRE(new CargoRE());
                    evaluadoRE.getCargoRE().setId(rs.getString("carg_id"));
                    evaluadoRE.getCargoRE().setNombre(rs.getString("carg_nombre"));

                    evaluadoRE.setId(rs.getString("eval_id"));
                    evaluadoRE.setAnnioEvaluacion(rs.getString("eval_anoevaluacion"));
                    evaluadoRE.setTiempo(rs.getString("eval_tiempo"));
                     evaluadoRE.setFechaPosesionStr( rs.getString( "fecha_posesion" ) );
                    evaluadoRE.setFechaPosesionStr(rs.getString("fecha_posesion"));
                    evaluadoRE.setActa(rs.getString("eval_acta"));
                    // evaluadoRE.setFechaInicio( rs.getTimestamp( "eval_fechainicio" ) );
                    evaluadoRE.setFechaInicioStr(rs.getString("fecha_inicio"));
                    // evaluadoRE.setFechaFin( rs.getTimestamp( "eval_fechafin" ) );
                    evaluadoRE.setFechaFinStr(rs.getString("fecha_fin"));
                    evaluadoRE.setVigencia(rs.getString("eval_vegencia"));

                    list.add(evaluadoRE);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadoDAO", "SQL listar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadoDAO", "listar( Object )", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        EvaluadoRE evaluadoRE = (EvaluadoRE) objeto;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluado.filtrar");
            api.addParameter(new Parameter(evaluadoRE.getId(), Types.NUMERIC));
            rs = (ResultSet) api.executeQuery();
            if (rs.next()) {
                evaluadoRE = new EvaluadoRE();
                // Datos personales de evaluado.
                evaluadoRE.setUsuarioRE(new UsuarioRE());
                evaluadoRE.getUsuarioRE().setId(rs.getString("usua_id"));
                evaluadoRE.getUsuarioRE().setPrimerNombre(rs.getString("usua_primernombre"));
                evaluadoRE.getUsuarioRE().setSegundoNombre(rs.getString("usua_segundonombre"));
                evaluadoRE.getUsuarioRE().setPrimerApellido(rs.getString("usua_primerapellido"));
                evaluadoRE.getUsuarioRE().setSegundoApellido(rs.getString("usua_segundoapellido"));
                evaluadoRE.getUsuarioRE().setNombreCompleto(rs.getString("nombre_completo"));
                evaluadoRE.getUsuarioRE().setOk(true);
                evaluadoRE.getUsuarioRE().setTipoDocumentoRE(new TipoDocumentoRE());
                evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setId(rs.getString("tido_id"));
                evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setAbreviatura(rs.getString("tido_abreviatura"));
                evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setNombre(rs.getString("tido_nombre"));
                evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setOk(true);
                // Cargo de evaluado.
                evaluadoRE.setCargoRE(new CargoRE());
                evaluadoRE.getCargoRE().setId(rs.getString("carg_id"));
                evaluadoRE.getCargoRE().setNombre(rs.getString("carg_nombre"));
                evaluadoRE.getCargoRE().setOk(true);
                evaluadoRE.setId(rs.getString("eval_id"));
                evaluadoRE.setAnnioEvaluacion(rs.getString("eval_anoevaluacion"));
                evaluadoRE.setTiempo(rs.getString("eval_tiempo"));
                evaluadoRE.setFechaPosesionStr(ConvertirFecha.timestampToString(rs.getTimestamp("eval_fechaposesion"), "dd-MM-yyyy"));
                evaluadoRE.setActa(rs.getString("eval_acta"));
                evaluadoRE.setFechaInicioStr(ConvertirFecha.timestampToString(rs.getTimestamp("eval_fechainicio"), "dd-MM-yyyy"));
                evaluadoRE.setFechaFinStr(ConvertirFecha.timestampToString(rs.getTimestamp("eval_fechafin"), "dd-MM-yyyy"));
                evaluadoRE.setVigencia(rs.getString("eval_vegencia"));
                evaluadoRE.setOk(true);
            }
        } catch (Exception e) {
            printException("buscar(Object objeto)", e);
            throw new EdaaException(e.getClass().getName(), "EvaluadoDAO", "buscar(Object objeto)", e.getMessage());
        } finally {
            try {
                api.close();
                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
        return evaluadoRE;
    }

    public Object buscarEvaluador(Object objeto) throws EdaaException {
        EvaluadoRE evaluadoRE=null;
        EvaluadorRE evaluadorRE_BUS = (EvaluadorRE) objeto;
        ResultSet rs = null;

        try
        {
            api.clear();
            api.addStrSql( "evaluado.buscar" );
            api.addParameter( new Parameter( evaluadorRE_BUS.getEvalId(), Types.NUMERIC ) );
            rs = (ResultSet) api.executeQuery();

            if ( rs.isBeforeFirst() )
            {
                evaluadoRE = new EvaluadoRE();
                if ( rs.next() )
                {

                    // Datos personales de evaluado.
                    evaluadoRE.setUsuarioRE( new UsuarioRE() );
                    evaluadoRE.getUsuarioRE().setId( rs.getString( "usua_id" ) );
                    evaluadoRE.getUsuarioRE().setPrimerNombre( rs.getString( "usua_primernombre" ) );
                    evaluadoRE.getUsuarioRE().setSegundoNombre( rs.getString( "usua_segundonombre" ) );
                    evaluadoRE.getUsuarioRE().setPrimerApellido( rs.getString( "usua_primerapellido" ) );
                    evaluadoRE.getUsuarioRE().setSegundoApellido( rs.getString( "usua_segundoapellido" ) );
                    evaluadoRE.getUsuarioRE().setNombreCompleto(rs.getString( "usua_primernombre" )+" "+rs.getString( "usua_primerapellido")+" "+rs.getString( "usua_segundoapellido" ))  ;
//                    evaluadoRE.getUsuarioRE().setTipoDocumentoRE( new TipoDocumentoRE() );
//                    evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setId( rs.getString( "tido_id" ) );
//                    evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setAbreviatura( rs.getString( "tido_abreviatura" ) );
//                    evaluadoRE.getUsuarioRE().getTipoDocumentoRE().setNombre( rs.getString( "tido_nombre" ) );

                    // Cargo de evaluado.
                    evaluadoRE.setCargoRE( new CargoRE() );
                    evaluadoRE.getCargoRE().setId( rs.getString( "carg_id" ) );
                    evaluadoRE.getCargoRE().setNombre( rs.getString( "carg_nombre" ) );

                    evaluadoRE.setId( rs.getString( "eval_id" ) );
                    evaluadoRE.setAnnioEvaluacion(rs.getString("eval_anoevaluacion"));
                    evaluadoRE.setTiempo(rs.getString("eval_tiempo"));
                     evaluadoRE.setFechaPosesionStr( rs.getString( "fecha_posesion" ) );
//                    evaluadoRE.setFechaPosesionStr( rs.getString( "fecha_posesion" ) );
                    evaluadoRE.setActa(rs.getString("eval_acta"));
                    // evaluadoRE.setFechaInicio( rs.getTimestamp( "eval_fechainicio" ) );
//                    evaluadoRE.setFechaInicioStr( rs.getString( "fecha_inicio" ) );
                    // evaluadoRE.setFechaFin( rs.getTimestamp( "eval_fechafin" ) );
//                    evaluadoRE.setFechaFinStr( rs.getString( "fecha_fin" ) );
                    evaluadoRE.setVigencia(rs.getString("eval_vegencia"));

                }
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadoDAO", "SQL buscar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadoDAO", "buscar( Object )", e.getMessage());
        } finally {
            try
            {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return evaluadoRE;
    }


    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }

    // 24-02-2021 @: Jesús Sierra
    /**
     * Método que actualiza el estado de un evaluado.
     * @param evaluadoRE - con el nuevo estado y id de evaluado.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    public void actualizarEstado( EvaluadoRE evaluadoRE ) throws EdaaException
    {
        try
        {
            if ( null != evaluadoRE )
            {
                api.clear();
                api.addStrSql("evaluado.actualizarEstado");
                api.addParameter( new Parameter( evaluadoRE.getEstado(), Types.NUMERIC ) );
                api.addParameter( new Parameter( evaluadoRE.getRegistradoPor(), Types.VARCHAR ) );
                api.addParameter( new Parameter( evaluadoRE.getId(), Types.NUMERIC ) );
                int res = api.executeUpdate();
                evaluadoRE.setOk( 1 == res );
            }
        } catch (SQLException e) {
            evaluadoRE.setOk(false);
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadorDAO", "SQL actualizarEstado( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadorDAO", "actualizarEstado( Object )", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    /**
     * lista los evaluados por el cargo
     *
     * @return
     * @throws EdaaException 20-02-2021 Francisco Geraldino Fernandez
     */
    public Object listarByCargo(Object objeto) throws EdaaException {
        EvaluadoRE RE_BUS = (EvaluadoRE) objeto;
        ArrayList<EvaluadoRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluado.listarCargo");
            api.addParameter(new Parameter(RE_BUS.getCargId(), Types.NUMERIC));
            rs = (ResultSet) api.executeQuery();
            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EvaluadoRE evaluadoRE;
                UsuarioRE usuario;
                while (rs.next()) {
                    evaluadoRE = new EvaluadoRE();
                    evaluadoRE.setId(rs.getString("eval_id"));
//                    evaluadoRE.setFechaInicio(rs.getString("eval_fechainicio"));
                    evaluadoRE.setUsuaId(rs.getString("usua_id"));
                    evaluadoRE.setCargId(rs.getString("carg_id"));
                    evaluadoRE.setAnnioEvaluacion(rs.getString("eval_anoevaluacion"));
                    evaluadoRE.setTiempo(rs.getString("eval_tiempo"));
//                    evaluadoRE.setFechaPosesion(rs.getString("eval_fechaposesion"));
                    evaluadoRE.setActa(rs.getString("eval_acta"));
                    evaluadoRE.setVigencia(rs.getString("eval_vegencia"));
//                    evaluadoRE.setFechaFin(rs.getString("eval_fechafin"));
                    evaluadoRE.setOk(true);

                    usuario = new UsuarioRE();

                    usuario.setId(rs.getString("usua_id"));
                    usuario.setDocumento(rs.getString("usua_documento"));
                    usuario.setEmail(rs.getString("usua_email"));
                    usuario.setPrimerNombre(rs.getString("usua_primernombre"));
                    usuario.setSegundoNombre(rs.getString("usua_segundonombre"));
                    usuario.setPrimerApellido(rs.getString("usua_primerapellido"));
                    usuario.setSegundoApellido(rs.getString("usua_segundoapellido"));

                    evaluadoRE.setUsuarioRE(usuario);
                    list.add(evaluadoRE);
                }
            }
        } catch (Exception e) {
            printException("listarByAnnioPresentacion(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listarByAnnioPresentacion(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    /**
     * lista los evaluados por el año de presentación
     *
     * @return
     * @throws EdaaException 20-02-2021 Francisco Geraldino Fernandez
     */
    public Object listarByAnnioPresentacion(Object objeto) throws EdaaException {
        EvaluadoRE RE_BUS = (EvaluadoRE) objeto;
        ArrayList<EvaluadoRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluado.listarByAnnioPresentacion");
            api.addParameter(new Parameter(RE_BUS.getAnnioEvaluacion(), Types.NUMERIC));
            rs = (ResultSet) api.executeQuery();
            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EvaluadoRE evaluadoRE;
                UsuarioRE usuario;
                while (rs.next()) {
                    evaluadoRE = new EvaluadoRE();
                    evaluadoRE.setId(rs.getString("eval_id"));
//                    evaluadoRE.setFechaInicio(rs.getString("eval_fechainicio"));
                    evaluadoRE.setUsuaId(rs.getString("usua_id"));
                    evaluadoRE.setCargId(rs.getString("carg_id"));
                    evaluadoRE.setAnnioEvaluacion(rs.getString("eval_anoevaluacion"));
                    evaluadoRE.setTiempo(rs.getString("eval_tiempo"));
                    evaluadoRE.setFechaPosesionStr(rs.getString("fecha_posesion"));
                    evaluadoRE.setActa(rs.getString("eval_acta"));
                    evaluadoRE.setVigencia(rs.getString("eval_vegencia"));
//                    evaluadoRE.setFechaFin(rs.getString("eval_fechafin"));
                    evaluadoRE.setOk(true);

                    usuario = new UsuarioRE();

                    usuario.setId(rs.getString("usua_id"));
                    usuario.setDocumento(rs.getString("usua_documento"));
                    usuario.setEmail(rs.getString("usua_email"));
                    usuario.setPrimerNombre(rs.getString("usua_primernombre"));
                    usuario.setSegundoNombre(rs.getString("usua_segundonombre"));
                    usuario.setPrimerApellido(rs.getString("usua_primerapellido"));
                    usuario.setSegundoApellido(rs.getString("usua_segundoapellido"));

                    evaluadoRE.setUsuarioRE(usuario);
                    list.add(evaluadoRE);
                }
            }
        } catch (Exception e) {
            printException("listarByAnnioPresentacion(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listarByAnnioPresentacion(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    /**
     * Lista de objeto PoblacionVO
     *
     * @return ArrayList
     * @throws EdaaException 24-02-2021 Mario Alejandro Rangel Guerrero
     */
    public ArrayList<PoblacionVO> obtenerDatosGeneralesEvaluado(Object object) throws EdaaException {
        String idEvaluado = (String) object;
        ResultSet rs = null;
        ArrayList<PoblacionVO> list = null;
        try {
            api.clear();
            api.addStrSql("evaluado.obtenerDatosGenerales");
            api.addParameter(new Parameter(idEvaluado, Types.NUMERIC));
            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                PoblacionVO poblacionVO;
                while (rs.next()) {
                    poblacionVO = new PoblacionVO();

                    poblacionVO.setPoblacion(rs.getString("poblacion"));
                    poblacionVO.setCantidad(rs.getShort("cantidad"));
                    poblacionVO.setPuntaje(rs.getDouble("puntaje"));
                    poblacionVO.setOk(true);

                    list.add(poblacionVO);
                }
            }
        } catch (Exception e) {
            printException("obtenerDatosGeneralesEvaluado(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "obtenerDatosGeneralesEvaluado(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }
}
