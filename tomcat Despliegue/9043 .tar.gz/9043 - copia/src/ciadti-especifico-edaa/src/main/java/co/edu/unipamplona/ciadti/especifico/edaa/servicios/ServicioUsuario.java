package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.Procesos;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;
import com.google.gson.Gson;

import javax.annotation.security.PermitAll;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Path("/user")
public class ServicioUsuario {

    @GET
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response listar() {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            Object list = fachadaAdministrador.listarUsuarios();

            if (null != list)
                return Response.ok(list).build();

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("Listar Usuarios");
            respuestaVO.setMensaje("No existen usuarios.");

            return Response.ok(gson.toJson(respuestaVO)).build();
        } catch (EdaaException ex) {
            if (null != ex.getStatus())
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()));
            else
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        }
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(UsuarioRE usuarioRE) {
        FachadaAdministrador fachadaAdministrador;
        RespuestaVO respuestaVO;

        try {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            fachadaAdministrador.insertarUsuario(usuarioRE);

            respuestaVO = new RespuestaVO();

            respuestaVO.setProceso("Registrar usuario");
            if (usuarioRE.isOk()) {
                respuestaVO.setMensaje("Se ha registrado el usuario correctamente.");
                respuestaVO.setOk(true);
                respuestaVO.setEstado(1);
                return Response.ok(respuestaVO).build();
            }

            respuestaVO.setMensaje("No se pudo registrar el usuario.");
            return Response.ok(respuestaVO).build();
        } catch (EdaaException ex) {
            if (null != ex.getStatus())
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()));
            else
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        }
    }

    @DELETE
    @Path("/{id}/{user}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response eliminar(@PathParam("id") String id, @PathParam("user") String user) {
        FachadaAdministrador fachadaAdministrador;
        RespuestaVO respuestaVO;

        try {
            UsuarioRE usuarioRE = new UsuarioRE();
            usuarioRE.setId(id);
            usuarioRE.setRegistradoPor(user);

            fachadaAdministrador = FachadaAdministrador.getInstancia();
            fachadaAdministrador.eliminarUsuario(usuarioRE);

            respuestaVO = new RespuestaVO();

            respuestaVO.setProceso("Eliminar usuario");

            if (usuarioRE.isOk()) {
                respuestaVO.setMensaje("Se ha eliminado el usuario correctamente.");
                respuestaVO.setOk(true);
                respuestaVO.setEstado(1);
                return Response.ok(respuestaVO).build();
            }

            respuestaVO.setMensaje("No se pudo eliminar el usuario.");
            return Response.ok(respuestaVO).build();
        } catch (EdaaException ex) {
            if (null != ex.getStatus())
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()));
            else
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        }
    }

    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response actualizar(UsuarioRE usuarioRE) {
        FachadaAdministrador fachadaAdministrador;
        RespuestaVO respuestaVO;

        try {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            fachadaAdministrador.actualizarUsuario(usuarioRE);

            respuestaVO = new RespuestaVO();

            respuestaVO.setProceso("Actualizar usuario");
            if (usuarioRE.isOk()) {
                respuestaVO.setMensaje("Se ha actualizado el usuario correctamente.");
                respuestaVO.setOk(true);
                respuestaVO.setEstado(1);
                return Response.ok(respuestaVO).build();
            }

            respuestaVO.setMensaje("No se pudo actualizar el usuario.");
            return Response.ok(respuestaVO).build();
        } catch (EdaaException ex) {
            if (null != ex.getStatus())
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()));
            else
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        }
    }

    @PUT
    @Path("/userPass")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response actualizarUsuarioYContrasena(UsuarioRE usuarioRE) {
        FachadaAdministrador fachadaAdministrador;
        RespuestaVO respuestaVO;

        try {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            fachadaAdministrador.actualizarUsuarioYContrasena(usuarioRE);

            respuestaVO = new RespuestaVO();

            respuestaVO.setProceso("Actualizar usuario y contrase\u00f1a");
            if (usuarioRE.isOk()) {
                respuestaVO.setMensaje("Se ha actualizado el usuario y la contrase\u00f1a correctamente.");
                respuestaVO.setOk(true);
                respuestaVO.setEstado(1);
                return Response.ok(respuestaVO).build();
            }

            respuestaVO.setMensaje("No se pudo actualizar el usuario y la contrase\u00f1a.");
            return Response.ok(respuestaVO).build();
        } catch (EdaaException ex) {
            if (null != ex.getStatus())
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()));
            else
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        }
    }

    /*@POST
    @Path("/buscarPersona")
    @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response buscarPersona( UsuarioAcademicoVO usuarioAcademicoVO )
    {
        FachadaAdministrador fachadaAdministrador;
        PersonaRE personaRE;

        try
        {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            personaRE = fachadaAdministrador.buscarPersonaAcademicoUP( usuarioAcademicoVO );

            if ( null != personaRE )
                return Response.ok( personaRE ).build();
            else
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException( "Sin datos", "Persona no encontrada para el perfil seleccionado.", "503" );
        } catch (co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }

    @POST
    @Path("/modificar")
    @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response modificar( MovilidadRE movilidadRE, @Context HttpServletRequest request )
    {
        FachadaAdministrador fachadaAdministrador;
        JWTClaimsSet claimSet;
        RespuestaVO respuestaVO;
        String authHeader;
        String respuesta;

        try
        {
            authHeader = request.getHeader( HttpHeaders.AUTHORIZATION );
            claimSet = (JWTClaimsSet) AuthUtils.decodeToken( authHeader );
            movilidadRE.setRegistradoPor( claimSet.getSubject() );
            movilidadRE.setPegeIdUsuario( claimSet.getStringClaim( "pegeId" ) );
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            respuesta = fachadaAdministrador.modificarMovilidad( movilidadRE );

            if ( Constantes.MODIFICADO.equals( respuesta ) )
            {
                respuestaVO = new RespuestaVO();
                respuestaVO.setProceso( "actualizar movilidad" );
                return Response.ok(respuestaVO).build();
            }
            else if ( "FALLO_ARCHIVO".equals( respuesta ) )
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException("BACK", "No se ha podido procesar su solicitud debido a que no se ha logrado almacenar un archivo.", "503");
            else if ( "FALLO_REPOSITORIO".equals( respuesta ) )
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException("BACK", "No se ha encontrado repositorio activo donde almacenar sus archivos.", "503");
            else
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException("BACK", "No se ha podido procesar su solicitud.", "503");
        } catch (co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }

    @DELETE
    @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response eliminar( MovilidadRE movilidadRE, @Context HttpServletRequest request )
    {
        FachadaAdministrador fachadaAdministrador;
        JWTClaimsSet claimSet;
        RespuestaVO respuestaVO;
        String authHeader;
        String respuesta;

        try
        {
            authHeader = request.getHeader( HttpHeaders.AUTHORIZATION );
            claimSet = (JWTClaimsSet) AuthUtils.decodeToken(authHeader);
            movilidadRE.setRegistradoPor( claimSet.getSubject() );
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            respuesta = fachadaAdministrador.eliminarMovilidad( movilidadRE );

            if ( Constantes.ELIMINADO.equals( respuesta ) )
            {
                respuestaVO = new RespuestaVO();
                respuestaVO.setProceso( "eliminar movilidad" );
                return Response.ok(respuestaVO).build();
            }
            else if ( "ESTADO_NO_REGISTRADO".equals( respuesta ) )
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException("BACK", "Solo se puede procesar su solicitud si la movilidad se encuentra en estado REGISTRADO.", "503");
            else
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException("BACK", "No se ha podido realizar su solicitud.", "503");

        } catch (co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }

    @POST
    @Path("/ver")
    @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response ver( MovilidadRE movilidadRE )
    {
        FachadaAdministrador fachadaAdministrador;

        try
        {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            movilidadRE = fachadaAdministrador.verMovilidad( movilidadRE );

            if ( null != movilidadRE )
                return Response.ok( movilidadRE ).build();
            else
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException( "Sin datos", "Movilidad no encontrada.", "503" );
        } catch (co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }
    
    @POST
    @Path("/listarEntrantes")
    @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response listarEntrantes( MovilidadRE movilidadRE )
    {
        ArrayList listaMovilidades;
        FachadaAdministrador fachadaAdministrador;

        try
        {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            listaMovilidades = fachadaAdministrador.listarMovilidadesEntrantes( movilidadRE );

            if ( null != listaMovilidades )
                return Response.ok( listaMovilidades ).build();
            else
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException( "Sin datos", "No hay movilidades entrantes para mostrar.", "503" );
        } catch (co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }
    
    
    @POST
    @Path("/archivosMovilidad")
    @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response listarArchivosMovilidad( MovilidadRE movilidadRE ){
        ArrayList listaArchivos;
        FachadaAdministrador fachadaAdministrador;

        try{
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            listaArchivos = fachadaAdministrador.listarArchivosMovilidad( movilidadRE );

            if ( null != listaArchivos )
                return Response.ok( listaArchivos ).build();
            else
                throw new co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException( "Sin datos", "No hay archivos para la movilidad.", "503" );
        } catch (co.edu.unipamplona.ciadti.especifico.movilidad.excepciones.EdaaException ex) {
            if ( null != ex.getStatus() )
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()) );
            else
                return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError( ex, MediaType.APPLICATION_JSON );
        }
    }*/
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
