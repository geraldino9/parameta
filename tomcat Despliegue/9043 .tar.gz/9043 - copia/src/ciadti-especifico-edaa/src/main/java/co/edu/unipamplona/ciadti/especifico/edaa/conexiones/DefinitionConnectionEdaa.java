package co.edu.unipamplona.ciadti.especifico.edaa.conexiones;

import especifico.interfaces.IDefinitionConnection;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class DefinitionConnectionEdaa implements IDefinitionConnection
{
    private Context initCtx;
    private Context envCtx;
    private DataSource ds;
    private Connection con;

    public DefinitionConnectionEdaa() throws SQLException, Exception
    {
        initCtx = null;
        envCtx = null;
        ds = null;
        con = null;

        try
        {
            initCtx = new InitialContext();
            envCtx = (Context) initCtx.lookup( "java:comp/env" );
            ds = (DataSource) envCtx.lookup( "jdbc/edaa" );
            con = ds.getConnection();
        } catch( SQLException e ) {
            System.out.println( "Error - no se puedo cargar el controlador en DefinitionConnectionEdaa --> " + e.getMessage() );
            con = null;
            e.printStackTrace( System.out );
            throw e;
        } catch( Exception e ) {
            System.out.println( "Error general en DefinitionConnectionEdaa --> " + e.getMessage() );
            con = null;
            e.printStackTrace( System.out );
            throw e;
        }
    }

    public DefinitionConnectionEdaa( Connection conexion )
    {
        initCtx = null;
        envCtx = null;
        ds = null;
        con = null;
        setConnection( conexion );
    }

    @Override
    public Connection getConnection() throws SQLException {
        if ( con != null )
            return con;
        else
            throw new SQLException( "Error ::> DefinitionConnectionEdaa ::> getConnection()" );
    }

    @Override
    public void setConnection(Connection cnctn) {
        con = cnctn;
    }

    @Override
    public Connection createConnection() throws SQLException {
        Connection conexion;

        try {
            conexion = ds.getConnection();
        } catch( SQLException e ) {
            System.out.println( "Error --> DefinitionConnectionEdaa ::> createConnection() " + e.getMessage() );
            e.printStackTrace( System.out );
            throw e;
        }

        return conexion;
    }

    @Override
    public void commit() throws SQLException {
        if ( con != null )
            con.commit();
    }

    @Override
    public void rollback() throws SQLException {
        if ( con != null )
            con.rollback();
    }

    @Override
    public void setAutoCommit(boolean bln) throws SQLException {
        con.setAutoCommit( bln );
    }

    @Override
    public void startTransaction() throws SQLException {
        this.setAutoCommit( false );
    }

    @Override
    public void finishTransaction(boolean exito) throws SQLException {
        if ( exito )
            this.commit();
        else
            this.rollback();

        this.setAutoCommit(true);
    }

    @Override
    public boolean isOpened() {
        boolean opened = true;

        try
        {
            if ( con == null )
                opened = false;
            else if ( con.isClosed() )
                opened = false;
        } catch( SQLException e ) {
            System.out.println( "Error ::> DefinitionConnectionEdaa ::> isOpened() " + e.getMessage() );
            e.printStackTrace( System.out );
        } catch( Exception e ) {
            System.out.println( "Error --> DefinitionConnectionEdaa ::> isOpened() " + e.getMessage() );
            e.printStackTrace( System.out );
        }

        return opened;
    }

    @Override
    public void close() throws SQLException, Exception {
        try
        {
            if ( isOpened() ) {
                con.close();
                con = null;
            }
        } catch( SQLException e ) {
            System.out.println( "Error --> DefinitionConnectionEdaa ::> close() " + e.getMessage() );
            e.printStackTrace( System.out );
            throw e;
        }
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
