package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import java.sql.Timestamp;

public class EvaluadorRE {
    private String id;
    private String usuaId;
    private String evalId;
    private Timestamp fecha;
    private String estado;
    private String observacion;
    private Double promedio;
    private String registradoPor;
    private Timestamp fechaRegistro;
    private boolean ok;
    private UsuarioRE usuarioRE;

    public EvaluadorRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsuaId() {
        return usuaId;
    }

    public void setUsuaId(String usuaId) {
        this.usuaId = usuaId;
    }

    public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public Double getPromedio() {
        return promedio;
    }

    public void setPromedio(Double promedio) {
        this.promedio = promedio;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public UsuarioRE getUsuarioRE() {
        return usuarioRE;
    }

    public void setUsuarioRE(UsuarioRE usuarioRE) {
        this.usuarioRE = usuarioRE;
    }
}
