package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.RolUsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;
import com.google.gson.Gson;

import javax.annotation.security.PermitAll;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Path("/rol")
public class ServicioRol {

    @GET
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarRoles() {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            fachadaAdministrador = FachadaAdministrador.getInstancia();
            Object list = fachadaAdministrador.listarRoles();

            if (list != null) {
                return Response.ok(list).build();
            }

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("Listar roles");
            respuestaVO.setMensaje("No existen roles.");

            return Response.ok(respuestaVO).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }

    @GET
    @Path("/user/{userId}")
    @PermitAll
    @Produces(MediaType.APPLICATION_JSON)
    public Response filtrarRoles(@PathParam("userId") String userId) {
        FachadaAdministrador fachadaAdministrador;
        Gson gson = new Gson();
        try {
            UsuarioRE usuarioRE = new UsuarioRE();
            usuarioRE.setId(userId);
            RolUsuarioRE rolUsuarioRE = new RolUsuarioRE();
            rolUsuarioRE.setUsuarioRE(usuarioRE);

            fachadaAdministrador = FachadaAdministrador.getInstancia();
            Object list = fachadaAdministrador.filtrarRoles(rolUsuarioRE);

            if (list != null) {
                return Response.ok(list).build();
            }

            RespuestaVO respuestaVO = new RespuestaVO();
            respuestaVO.setOk(false);
            respuestaVO.setProceso("Filtrar Roles por Usuario");
            respuestaVO.setMensaje("El usuario no tiene roles asociados");

            return Response.ok(respuestaVO).build();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return Response.status(500).entity(gson.toJson("Error interno del servidor [500].")).type(MediaType.APPLICATION_JSON).build();
        }
    }
}
/*
 *  19/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : CREACIÓN
 *
 */
