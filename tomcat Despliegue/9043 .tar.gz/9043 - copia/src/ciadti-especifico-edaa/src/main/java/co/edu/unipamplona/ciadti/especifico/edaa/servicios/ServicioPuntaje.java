package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.PuntajeRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.fachadas.FachadaAdministrador;
import co.edu.unipamplona.ciadti.especifico.edaa.utilidades.Procesos;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.RespuestaVO;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@Path("/puntajes")
public class ServicioPuntaje {
    @POST
    // @RolesAllowed("ADMINISTRADOR")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(PuntajeRE puntajeRE) {
        try {
            FachadaAdministrador fachadaAdministrador = FachadaAdministrador.getInstancia();
            String proceso = fachadaAdministrador.registrarPuntaje(puntajeRE);

            if ("REGISTRADO".equals(proceso)) {
                RespuestaVO respuestaVO = new RespuestaVO();
                respuestaVO.setEstado(200);
                respuestaVO.setOk(true);
                respuestaVO.setProceso("registrar puntaje");
                return Response.ok(respuestaVO).build();
            } else {
                throw new EdaaException("Error", "No se ha podido registrar su solicitud.", "503");
            }
        } catch (EdaaException ex) {
            if (null != ex.getStatus())
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON, Integer.parseInt(ex.getStatus()));
            else
                return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
            return Procesos.procesarError(ex, MediaType.APPLICATION_JSON);
        }
    }
}
/*
 *  24/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
