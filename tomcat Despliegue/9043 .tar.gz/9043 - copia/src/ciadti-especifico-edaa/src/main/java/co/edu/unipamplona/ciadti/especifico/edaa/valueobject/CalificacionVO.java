package co.edu.unipamplona.ciadti.especifico.edaa.valueobject;

import java.util.List;

/**
 *
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class CalificacionVO
{
    private String idEvaluado;
    private String idUsuario; // id de usuario evaluador.
    private List<Respuesta> respuestas;
    private String registradoPor;
    private String observacion;

    public CalificacionVO() {
    }

    public String getIdEvaluado() {
        return idEvaluado;
    }

    public void setIdEvaluado(String idEvaluado) {
        this.idEvaluado = idEvaluado;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public List<Respuesta> getRespuestas() {
        return respuestas;
    }

    public void setRespuestas(List<Respuesta> respuestas) {
        this.respuestas = respuestas;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public static class Respuesta
    {
        private String idFormPregunta;
        private String idValor;
        private String valor;

        public Respuesta() {
        }

        public String getIdFormPregunta() {
            return idFormPregunta;
        }

        public void setIdFormPregunta(String idFormPregunta) {
            this.idFormPregunta = idFormPregunta;
        }

        public String getIdValor() {
            return idValor;
        }

        public void setIdValor(String idValor) {
            this.idValor = idValor;
        }

        public String getValor() {
            return valor;
        }

        public void setValor(String valor) {
            this.valor = valor;
        }
    }
}
/*
 *  21/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
