package co.edu.unipamplona.ciadti.especifico.edaa.valueobject;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.FormularioRE;

import java.util.Map;

public class DatosPDFVO {
    private FormularioRE formulario;
    private String idEvaluador;
    private EvaluadoRE evaluadoRE;
    private EvaluadorRE evaluadorRE;
    private String archivoB64;
    private Map caracteristicas;

    public DatosPDFVO() {
    }

    public FormularioRE getFormulario() {
        return formulario;
    }

    public void setFormulario(FormularioRE formulario) {
        this.formulario = formulario;
    }

    public String getIdEvaluador() {
        return idEvaluador;
    }

    public void setIdEvaluador(String idEvaluador) {
        this.idEvaluador = idEvaluador;
    }

    public EvaluadoRE getEvaluadoRE() {
        return evaluadoRE;
    }

    public void setEvaluadoRE(EvaluadoRE evaluadoRE) {
        this.evaluadoRE = evaluadoRE;
    }

    public EvaluadorRE getEvaluadorRE() {
        return evaluadorRE;
    }

    public void setEvaluadorRE(EvaluadorRE evaluadorRE) {
        this.evaluadorRE = evaluadorRE;
    }

    public String getArchivoB64() {
        return archivoB64;
    }

    public void setArchivoB64(String archivoB64) {
        this.archivoB64 = archivoB64;
    }

    public Map getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(Map caracteristicas) {
        this.caracteristicas = caracteristicas;
    }
}
