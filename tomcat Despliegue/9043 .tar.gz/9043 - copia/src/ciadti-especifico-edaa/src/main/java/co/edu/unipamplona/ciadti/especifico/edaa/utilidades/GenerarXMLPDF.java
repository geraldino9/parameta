package co.edu.unipamplona.ciadti.especifico.edaa.utilidades;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.*;
import co.edu.unipamplona.ciadti.especifico.edaa.valueobject.DatosPDFVO;
import org.apache.avalon.framework.logger.Logger;
import org.apache.avalon.framework.logger.NullLogger;
import org.apache.fop.apps.Driver;
import org.apache.fop.messaging.MessageHandler;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class GenerarXMLPDF {

    public Object generarXMLGeneral(DatosPDFVO datos) {
        StringBuffer pageXML = null;
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd 'de' MMMMM 'de' yyyy", new Locale("es"));
        String fechaActual = sdf.format(Calendar.getInstance().getTime());
        Map caracteristicas = null;
        ArrayList<ValorRE> valores = null;
        Context ctx = null;
        try {
            ctx = new InitialContext();
            Context env = (Context) ctx.lookup("java:comp/env");
            final String rutaArchivos = (String) env.lookup("rutaArchivos");

            caracteristicas = datos.getCaracteristicas();
            if (caracteristicas != null) {
                Set<String> keys = caracteristicas.keySet();


                pageXML = new StringBuffer();
                pageXML.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
                pageXML.append("\n<formulario xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"../xslt/formulario.xsd\">");

//                pageXML.append("\n <datos>");
                pageXML.append("\n<reporte>");
                pageXML.append("\n<rutaImagenes>" + rutaArchivos + "informesPDF/images/</rutaImagenes>");
                pageXML.append("\n<fechaActual>" + fechaActual + "</fechaActual>");
                //información del evaluador
                pageXML.append("\n<nombreEvdr>" + datos.getEvaluadorRE().getUsuarioRE().getNombreCompleto() + "</nombreEvdr>");
                pageXML.append("\n<documentoEvdr>" + datos.getEvaluadorRE().getUsuarioRE().getDocumento() + "</documentoEvdr>");
                pageXML.append("\n<promedio>" + datos.getEvaluadorRE().getPromedio() + "</promedio>");

                //Informacion del evaluado
                pageXML.append("\n<docente1>jajajaja</docente1>");
                pageXML.append("\n<docente>" + datos.getEvaluadoRE().getUsuarioRE().getNombreCompleto() + "</docente>");

                pageXML.append("\n<cargo>" + datos.getEvaluadoRE().getCargoRE().getNombre() + "</cargo>");
                pageXML.append("\n<tiempo>" + datos.getEvaluadoRE().getTiempo() + "</tiempo>");
                pageXML.append("\n<fechaPosecion>" + datos.getEvaluadoRE().getFechaPosesionStr() + "</fechaPosecion>");
                pageXML.append("\n<acta>" + datos.getEvaluadoRE().getActa() + "</acta>");
                pageXML.append("\n<annio>" + datos.getEvaluadoRE().getAnnioEvaluacion() + "</annio>");

                FormularioRE formularioRE = datos.getFormulario();
                for (GrupoValorRE grupoValor : formularioRE.getListaGruposValor()) {
                    valores = (ArrayList<ValorRE>) grupoValor.getListaValores();

                }
                if (valores != null) {
                    pageXML.append(generarXmlValores(valores));
                }

                ArrayList<FormularioPreguntaRE> aux = null;
                for (String key : keys) {
                    pageXML.append("\n<caracteristicas>");
                    aux = (ArrayList<FormularioPreguntaRE>) caracteristicas.get(key);
                    pageXML.append("\n<caracteristica>" + key + "</caracteristica>");
                    if (aux != null && aux.size() > 0) {
                        for (FormularioPreguntaRE fopr : aux) {
                            pageXML.append("\n<preguntas>");
                            pageXML.append("\n<orden>" + fopr.getOrden() + "</orden>");
                            pageXML.append("\n<pregunta>" + fopr.getPreguntaRE().getContenido() + "</pregunta>");
                            //pageXML.append("\n<calificacion>"+fopr.getCalificacionRE().getRespuesta()+"</calificacion>");

                            for (ValorRE valor : valores) {
                                pageXML.append("\n<calificaciones>");
                                if(fopr.getCalificacionRE().getValoId() != null){
                                    if (fopr.getCalificacionRE().getValoId().equals(valor.getId())) {
                                        pageXML.append("\n<calificacion>X</calificacion>");
                                    } else {
                                        pageXML.append("\n<calificacion></calificacion>");
                                    }
                                }else{
                                    pageXML.append("\n<calificacion></calificacion>");
                                }
                                pageXML.append("\n</calificaciones>");
                            }
                            pageXML.append("\n</preguntas>");
                        }
                    } else {
                        System.out.println("la lista de " + key + " esta vacia");
                    }
                    pageXML.append("\n</caracteristicas>");
                }

                pageXML.append("\n</reporte>");
                pageXML.append("\n</formulario>");
            }

        } catch (Exception e) {
            System.out.println("Error ::: GenerarXML :::  generarXMLGeneral :: " + e.getMessage());
            e.printStackTrace();
        }
//        System.out.println("pageXML General "+ pageXML);
        return pageXML;
    }

    public void organizarPorCaracteristica() {
    }

    ;

    public Object generarXmlValores(ArrayList<ValorRE> lista) {
        StringBuffer pageXML = null;
        try {
            pageXML = new StringBuffer();

            for (ValorRE valor : lista) {
                pageXML.append("\n<valor>");
                pageXML.append("\n<nombre>" + valor.getDescripcion() + "</nombre>");
                pageXML.append("\n<abreviatura>" + valor.getAbreviatura() + "</abreviatura>");
                pageXML.append("\n</valor>");
            }

        } catch (Exception e) {
            System.out.println("Error ::: GenerarXML :::  generarXMLGeneral :: " + e.getMessage());
            e.printStackTrace();
        }
        return pageXML;
    }


    /**
     * ESTE METODO GENERA EL PDF
     *
     * @param pageXML
     * @return
     */
    public String generarPDFFileByEvaluador(StringBuffer pageXML) {
        String ubicacion = "";
        String separador = System.getProperty("file.separator");
        String[] nombreMes = {"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"};
        Calendar fechaInicio = Calendar.getInstance();
        String fechaActual = "[ " + fechaInicio.get(Calendar.DATE) + "-" + nombreMes[fechaInicio.get(Calendar.MONTH)] + "-" + fechaInicio.get(Calendar.YEAR) + " | " + fechaInicio.get(Calendar.HOUR_OF_DAY) + ":" + fechaInicio.get(Calendar.MINUTE) + ":" + fechaInicio.get(Calendar.SECOND) + " ]";
        File xmlfile = null;
        Context ctx = null;
        String base64 = null;
        try {
            ctx = new InitialContext();
            Context env = (Context) ctx.lookup("java:comp/env");
            final String rutaArchivos = (String) env.lookup("rutaArchivos");

            File baseDir = new File(rutaArchivos);
            File outDir = new File(baseDir, "informesPDF/pdf");
            outDir.mkdirs();
            try {
                if (pageXML != null) {
                    String ruta = rutaArchivos + separador + "informesPDF" + separador + "xml" + separador + "reporteEvaluador" + ".xml";
                    FileWriter archivoXML = new FileWriter(ruta);
                    BufferedWriter escritor = new BufferedWriter(archivoXML);
                    escritor.write(pageXML.toString());
                    escritor.close();
                }

            } catch (IOException ex) {
                System.out.println("::: Error ::: No se pudo escribir el archivo XML ::: " + ex.getMessage());
            }

            xmlfile = new File(baseDir, "informesPDF/xml/reporteEvaluador.xml");
            File xsltfile = new File(baseDir, "informesPDF/xslt/formulario.xsl");
            File pdffile = new File(outDir, "reporteEvaluador" + ".pdf");
            Driver driver = new Driver();//
            Logger logger = new NullLogger();
            driver.setLogger(logger);
            MessageHandler.setScreenLogger(logger);//
            driver.setRenderer(Driver.RENDER_PDF);
            OutputStream out = null;
            try {
                out = new FileOutputStream(pdffile);
                driver.setOutputStream(out);
                org.apache.xalan.processor.TransformerFactoryImpl factory = new org.apache.xalan.processor.TransformerFactoryImpl();
                Transformer transformer = factory.newTransformer(new StreamSource(xsltfile));
                transformer.setParameter("versionParam", "2.0");
                Source src = new StreamSource(xmlfile);
                Result res = new SAXResult(driver.getContentHandler());
                transformer.transform(src, res);

                base64 = Bytes.bytesToBase64(baseDir + "/informesPDF/pdf/reporteEvaluador.pdf");

                System.out.println("::: PDF Generado Correctamente ::: [ " + ubicacion + " ] ::: " + fechaActual);
            } catch (Exception ex){
                ex.printStackTrace();
            }finally {
                out.close();
            }

        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.out.println("Error ::: GenerarXMLPDF ::: generar() ::: Exception ::: " + e.getMessage());
            e.printStackTrace();
        } finally {
            //xmlfile.delete();
        }
//        System.out.println("base64: " + base64);
        return base64;
    }

    public Object generarXMLPuntajeEvaluado(EvaluadoRE evaluado){
        StringBuffer pageXML = null;
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd 'de' MMMMM 'de' yyyy", new Locale("es"));
        String fechaActual = sdf.format(Calendar.getInstance().getTime());

        ArrayList<ValorRE> valores = null;
        Context ctx = null;

        try{
            //rutra de archivo
            ctx = new InitialContext();
            Context env = (Context) ctx.lookup("java:comp/env");
            final String rutaArchivos = (String) env.lookup("rutaArchivos");

            pageXML = new StringBuffer();
            pageXML.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
            pageXML.append("\n<puntajeEvaluado xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:noNamespaceSchemaLocation=\"../xslt/puntajeEvaluado.xsd\">");
                pageXML.append("\n<reporte>");
                    pageXML.append("\n<rutaImagenes>" + rutaArchivos + "informesPDF/images/</rutaImagenes>");
                    pageXML.append("\n<fechaActual>" + fechaActual + "</fechaActual>");
                    pageXML.append("\n<docente>"+evaluado.getUsuarioRE().getNombreCompleto()+"</docente>");
                    pageXML.append("\n<cargo>"+evaluado.getCargoRE().getNombre()+"</cargo>");
                    pageXML.append("\n<annio>"+evaluado.getAnnioEvaluacion()+"</annio>");
                    pageXML.append("\n<tiempo>"+evaluado.getTiempo()+"</tiempo>");
                    pageXML.append("\n<fPosesion>"+evaluado.getFechaPosesionStr()+"</fPosesion>");
                    pageXML.append("\n<acta>"+evaluado.getActa()+"</acta>");
                    pageXML.append("\n<cEvaluadores>"+evaluado.getGeneralVO().getCantidad_evaluadores()+"</cEvaluadores>");
                    pageXML.append("\n<cParticipantes>"+evaluado.getGeneralVO().getCantidad_participantes()+"</cParticipantes>");
                    pageXML.append("\n<puntaje>"+evaluado.getGeneralVO().getPuntajeObtenido()+"</puntaje>");
                    pageXML.append("\n<promedio>"+evaluado.getGeneralVO().getPromedio()+"</promedio>");
                pageXML.append("\n</reporte>");
            pageXML.append("\n</puntajeEvaluado>");

        }catch(Exception e){e.printStackTrace();}


        return pageXML;
    }

    public String generarPDFFilePuntajeEvaluado(StringBuffer pageXML) {
        String ubicacion = "";
        String separador = System.getProperty("file.separator");
        String[] nombreMes = {"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"};
        Calendar fechaInicio = Calendar.getInstance();
        String fechaActual = "[ " + fechaInicio.get(Calendar.DATE) + "-" + nombreMes[fechaInicio.get(Calendar.MONTH)] + "-" + fechaInicio.get(Calendar.YEAR) + " | " + fechaInicio.get(Calendar.HOUR_OF_DAY) + ":" + fechaInicio.get(Calendar.MINUTE) + ":" + fechaInicio.get(Calendar.SECOND) + " ]";
        File xmlfile = null;
        Context ctx = null;
        String base64 = null;
        try {
            ctx = new InitialContext();
            Context env = (Context) ctx.lookup("java:comp/env");
            final String rutaArchivos = (String) env.lookup("rutaArchivos");

            File baseDir = new File(rutaArchivos);
            File outDir = new File(baseDir, "informesPDF/pdf");
            outDir.mkdirs();
            try {
                if (pageXML != null) {
                    String ruta = rutaArchivos + separador + "informesPDF" + separador + "xml" + separador + "puntajeEvaluado" + ".xml";
                    FileWriter archivoXML = new FileWriter(ruta);
                    BufferedWriter escritor = new BufferedWriter(archivoXML);
                    escritor.write(pageXML.toString());
                    escritor.close();
                }

            } catch (IOException ex) {
                System.out.println("::: Error ::: No se pudo escribir el archivo XML ::: " + ex.getMessage());
            }

            xmlfile = new File(baseDir, "informesPDF/xml/puntajeEvaluado.xml");
            File xsltfile = new File(baseDir, "informesPDF/xslt/puntajeEvaluado.xsl");
            File pdffile = new File(outDir, "puntajeEvaluado" + ".pdf");
            Driver driver = new Driver();//
            Logger logger = new NullLogger();
            driver.setLogger(logger);
            MessageHandler.setScreenLogger(logger);//
            driver.setRenderer(Driver.RENDER_PDF);
            OutputStream out = null;
            try {
                out = new FileOutputStream(pdffile);
                driver.setOutputStream(out);
                org.apache.xalan.processor.TransformerFactoryImpl factory = new org.apache.xalan.processor.TransformerFactoryImpl();
                Transformer transformer = factory.newTransformer(new StreamSource(xsltfile));
                transformer.setParameter("versionParam", "2.0");
                Source src = new StreamSource(xmlfile);
                Result res = new SAXResult(driver.getContentHandler());
                transformer.transform(src, res);

                base64 = Bytes.bytesToBase64(baseDir + "/informesPDF/pdf/puntajeEvaluado.pdf");

                System.out.println("::: PDF Generado Correctamente ::: [ " + ubicacion + " ] ::: " + fechaActual);
            } catch (Exception ex){
                ex.printStackTrace();
            }finally {
                out.close();
            }

        } catch (Exception e) {
            e.printStackTrace(System.err);
            System.out.println("Error ::: GenerarXMLPDF ::: generar() ::: Exception ::: " + e.getMessage());
            e.printStackTrace();
        } finally {
            //xmlfile.delete();
        }
//        System.out.println("base64: " + base64);
        return base64;
    }
}
