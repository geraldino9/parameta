package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import java.sql.Timestamp;

public class CalificacionRE {
    private String id;
    private String evalId;
    private String evdrId;
    private String foprId;
    private String valoId;
    private String registradoPor;
    private Timestamp fechaRegistro;
    private boolean ok;
    private String respuesta;


    public CalificacionRE() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId;
    }

    public String getEvdrId() {
        return evdrId;
    }

    public void setEvdrId(String evdrId) {
        this.evdrId = evdrId;
    }

    public String getFoprId() {
        return foprId;
    }

    public void setFoprId(String foprId) {
        this.foprId = foprId;
    }

    public String getValoId() {
        return valoId;
    }

    public void setValoId(String valoId) {
        this.valoId = valoId;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
}
