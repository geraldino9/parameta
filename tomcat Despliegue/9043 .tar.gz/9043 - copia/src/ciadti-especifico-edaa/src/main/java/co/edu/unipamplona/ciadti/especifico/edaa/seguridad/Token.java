package co.edu.unipamplona.ciadti.especifico.edaa.seguridad;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class Token {
    String token;

    public Token(@JsonProperty("token") String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}
/*
 *  11/07/2019: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */