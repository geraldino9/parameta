package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.*;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class FormularioPreguntaDAO implements IGeneralDAO, IPrintException {

    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "formularioPregunta", "postgresql");

    /**
     FormularioPreguntaDAO     *
     * @throws EdaaException EdaaException
     */
    public FormularioPreguntaDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("FormularioPreguntaDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de FormularioPreguntaDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public FormularioPreguntaDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("FormularioPreguntaDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {

    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {

        ArrayList<FormularioPreguntaRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("formularioPregunta.listarTodo");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                FormularioPreguntaRE formularioPreguntaRE;
                while (rs.next()) {
                    formularioPreguntaRE = new FormularioPreguntaRE();
                    formularioPreguntaRE.setId(rs.getString("fopr_id"));
                    formularioPreguntaRE.setFormId(rs.getString("carg_id"));
                    formularioPreguntaRE.setPregId(rs.getString("preg_id"));
                    formularioPreguntaRE.setOrden(rs.getShort("fopr_orden"));
                    formularioPreguntaRE.setOk(true);
                    list.add(formularioPreguntaRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que consulta las preguntas de un formulario con sus respectivas características y opciones
     * de respuesta para su correspondiente evaluado.
     * @param objeto - EvaluadoRE con el eval_id a consultar.
     * @return Lista de objetos FormularioPreguntaRE.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public Object listar( Object objeto ) throws EdaaException
    {
        EvaluadoRE evaluadoRE = (EvaluadoRE) objeto;
        FormularioPreguntaRE formularioPreguntaRE;
        List<FormularioPreguntaRE> list = null;
        ResultSet rs = null;

        try
        {
            api.clear();
            api.addStrSql( "formularioPregunta.listar" );
            api.addParameter( new Parameter( evaluadoRE.getId(), Types.NUMERIC ) );
            rs = (ResultSet) api.executeQuery();

            if ( rs.isBeforeFirst() )
            {
                list = new ArrayList<>();

                while ( rs.next() )
                {
                    formularioPreguntaRE = new FormularioPreguntaRE();
                    formularioPreguntaRE.setId( rs.getString( "fopr_id" ) );
                    formularioPreguntaRE.setOrden( rs.getShort( "fopr_orden" ) );

                    if ( 0 == list.size() ) // carga datos de formulario.
                    {
                        formularioPreguntaRE.setFormularioRE( new FormularioRE() );
                        formularioPreguntaRE.getFormularioRE().setId( rs.getString( "form_id" ) );
                        formularioPreguntaRE.getFormularioRE().setNombre( rs.getString( "form_nombre" ) );
                    }

                    // Carga datos de pregunta.
                    formularioPreguntaRE.setPreguntaRE( new PreguntaRE() );
                    formularioPreguntaRE.getPreguntaRE().setId( rs.getString( "preg_id" ) );
                    formularioPreguntaRE.getPreguntaRE().setContenido( rs.getString( "preg_contenido" ) );
                    // A la pregunta le carga datos de características.
                    formularioPreguntaRE.getPreguntaRE().setCaracteristicaRE( new CaracteristicaRE() );
                    formularioPreguntaRE.getPreguntaRE().getCaracteristicaRE().setId( rs.getString( "cara_id" ) );
                    formularioPreguntaRE.getPreguntaRE().getCaracteristicaRE().setNombre( rs.getString( "cara_nombre" ) );

                    if ( null != rs.getString( "grva_id" ) ) // A la pregunta le carga datos de grupoValor.
                    {
                        formularioPreguntaRE.getPreguntaRE().setGrupoValorRE( new GrupoValorRE() );
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().setId( rs.getString( "grva_id" ) );
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().setNombre( rs.getString( "grva_nombre" ) );
                        // Al grupoValor le carga datos del valor.
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().setValorRE( new ValorRE() );
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().setId( rs.getString( "valo_id" ) );
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().setDescripcion( rs.getString( "valo_descripcion" ) );
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().setPuntaje( rs.getDouble( "valo_puntaje" ) );
                        formularioPreguntaRE.getPreguntaRE().getGrupoValorRE().getValorRE().setAbreviatura( rs.getString( "valo_abreviatura" ) );
                    }

                    list.add( formularioPreguntaRE );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "FormularioPreguntaDAO", "SQL listar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "FormularioPreguntaDAO", "listar( Object )", e.getMessage());
        } finally {
            try
            {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }
}
