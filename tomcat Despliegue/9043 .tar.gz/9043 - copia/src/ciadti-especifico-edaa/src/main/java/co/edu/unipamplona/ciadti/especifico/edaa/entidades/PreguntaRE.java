package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import java.sql.Timestamp;

public class PreguntaRE {
    private String id;
    private String caraId;
    private String grvaId;
    private String contenido;
    private String registradoPor;
    private Timestamp fechaRegistro;
    private boolean ok;
    private CaracteristicaRE caracteristicaRE;
    private GrupoValorRE grupoValorRE;

    public PreguntaRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCaraId() {
        return caraId;
    }

    public void setCaraId(String caraId) {
        this.caraId = caraId;
    }

    public String getGrvaId() {
        return grvaId;
    }

    public void setGrvaId(String grvaId) {
        this.grvaId = grvaId;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public CaracteristicaRE getCaracteristicaRE() {
        return caracteristicaRE;
    }

    public void setCaracteristicaRE(CaracteristicaRE caracteristicaRE) {
        this.caracteristicaRE = caracteristicaRE;
    }

    public GrupoValorRE getGrupoValorRE() {
        return grupoValorRE;
    }

    public void setGrupoValorRE(GrupoValorRE grupoValorRE) {
        this.grupoValorRE = grupoValorRE;
    }
}
