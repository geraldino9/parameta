package co.edu.unipamplona.ciadti.especifico.edaa.servicios;

import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;

import javax.ws.rs.ApplicationPath;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
@ApplicationPath("servicios")
public class Configuracion extends ResourceConfig {
    public Configuracion() {
        packages("co.edu.unipamplona.ciadti.especifico.edaa.servicios;co.edu.unipamplona.ciadti.especifico.edaa.seguridad");
        register(RolesAllowedDynamicFeature.class);
        // register(MultiPartFeature.class);
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
