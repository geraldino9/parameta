package co.edu.unipamplona.ciadti.especifico.edaa.valueobject;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class GeneralVO {
    private Short cantidad_evaluadores;
    private Short cantidad_participantes;
    private Double puntajeObtenido;
    private String promedio;
    private boolean ok;

    public GeneralVO() {
    }

    public Short getCantidad_evaluadores() {
        return cantidad_evaluadores;
    }

    public void setCantidad_evaluadores(Short cantidad_evaluadores) {
        this.cantidad_evaluadores = cantidad_evaluadores;
    }

    public Short getCantidad_participantes() {
        return cantidad_participantes;
    }

    public void setCantidad_participantes(Short cantidad_participantes) {
        this.cantidad_participantes = cantidad_participantes;
    }

    public Double getPuntajeObtenido() {
        return puntajeObtenido;
    }

    public void setPuntajeObtenido(Double puntajeObtenido) {
        this.puntajeObtenido = puntajeObtenido;
    }

    public String getPromedio() {
        return promedio;
    }

    public void setPromedio(String promedio) {
        this.promedio = promedio;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }
}
/*
 *  23/02/2021: MARIO ALEJANDRO RANGEL GUERRERO : CREACIÓN
 *
 */
