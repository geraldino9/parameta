package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.TipoDocumentoRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import co.edu.unipamplona.ciadti.especifico.utilidades.Encriptacion;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * @author GRUPO DE DESARROLLO ESPECÍFICO - CIADTI - UNIVERSIDAD DE PAMPLONA
 */
public class UsuarioDAO implements IGeneralDAO, IPrintException {
    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "usuario", "postgresql");

    /**
     * Crea una nueva instancia de UsuarioDAO
     *
     * @throws EdaaException EdaaException
     */
    public UsuarioDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("UsuarioDAO()", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de UsuarioDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public UsuarioDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("UsuarioDAO(Object conexion)", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    /**
     * Método que inserta un registro a la entidad: EDAA.USUARIO
     *
     * @param objeto de tipo UsuarioRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void insertar(Object objeto) throws EdaaException {
        UsuarioRE usuarioRE = (UsuarioRE) objeto;
        String res;

        try {
            if (null != usuarioRE) {
                api.clear();
                api.addStrSql("usuario.insertarProcedure");
                api.addParameter(new Parameter(usuarioRE.getPrimerNombre(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getSegundoNombre(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getPrimerApellido(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getSegundoApellido(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getTipoDocumentoRE().getId(), Types.NUMERIC));
                api.addParameter(new Parameter(usuarioRE.getDocumento(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getEmail(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getUsuario(), Types.VARCHAR));
                api.addParameter(new Parameter(Encriptacion.getStringMessageDigest(usuarioRE.getContrasena(), "MD5", 3), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getRegistradoPor(), Types.VARCHAR));
                res = (String) api.executeProcedure(true);

                if (res != null && !res.equals("-1") && !res.equals("0")) {
                    usuarioRE.setId(res);
                    usuarioRE.setOk(true);
                }
            }
        } catch (SQLException e) {
            if ("23505".equals(e.getSQLState()))
                throw new EdaaException("Violate Foreign", "El documento, usuario o correo que esta intentando agregar ya existe en el sistema.", "500");

            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "insertar( Object )", e.getMessage());
        } catch (Exception e) {
            printException("insertar(Object objeto)", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "insertar( Object )", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    /**
     * Método que actualiza un registro de la entidad: EDAA.USUARIO
     *
     * @param objeto de tipo UsuarioRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void actualizar(Object objeto) throws EdaaException {
        UsuarioRE usuarioRE = (UsuarioRE) objeto;

        try {
            if (null != usuarioRE) {
                api.clear();
                api.addStrSql("usuario.actualizar");
                api.addParameter(new Parameter(usuarioRE.getTipoDocumentoRE().getId(), Types.NUMERIC));
                api.addParameter(new Parameter(usuarioRE.getDocumento(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getPrimerNombre(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getSegundoNombre(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getPrimerApellido(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getSegundoApellido(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getEmail(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getRegistradoPor(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getId(), Types.NUMERIC));
                usuarioRE.setOk(api.executeUpdate() > 0);
            }
        } catch (Exception e) {
            printException("actualizar(Object objeto)", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "actualizar(Object objeto)", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    /**
     * Método que elimina un registro de la entidad: EDAA.USUARIO
     *
     * @param objeto de tipo UsuarioRE, setea el estado del proceso por referencia
     * @throws EdaaException EdaaException
     */
    @Override
    public void eliminar(Object objeto) throws EdaaException {
        UsuarioRE usuarioRE = (UsuarioRE) objeto;
        String res;

        try {
            if (null != usuarioRE) {
                api.clear();
                api.addStrSql("usuario.eliminarProcedure");
                api.addParameter(new Parameter(usuarioRE.getId(), Types.NUMERIC));
                api.addParameter(new Parameter(usuarioRE.getRegistradoPor(), Types.VARCHAR));
                res = (String) api.executeProcedure(true);
                usuarioRE.setOk("1".equals(res));
            }
        } catch (SQLException e) {
            if ("23503".equals(e.getSQLState()))
                throw new EdaaException("Violate Foreign", "No se puede eliminar porque tiene uno o más roles asociados.", "500");

            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "eliminar(Object objeto)", e.getMessage());
        } catch (Exception e) {
            printException("eliminar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "eliminar(Object objeto)", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public Object listar() throws EdaaException {
        ArrayList<UsuarioRE> lista = null;
        UsuarioRE usuarioRE;
        ResultSet rs = null;

        try {
            api.clear();
            api.addStrSql("usuario.listar");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                lista = new ArrayList<>();
                TipoDocumentoRE tipoDocumentoRE;

                while (rs.next()) {
                    usuarioRE = new UsuarioRE();
                    usuarioRE.setId(rs.getString("usua_id"));
                    usuarioRE.setPrimerNombre(rs.getString("usua_primernombre"));
                    usuarioRE.setSegundoNombre(rs.getString("usua_segundonombre"));
                    usuarioRE.setPrimerApellido(rs.getString("usua_primerapellido"));
                    usuarioRE.setSegundoApellido(rs.getString("usua_segundoapellido"));

                    tipoDocumentoRE = new TipoDocumentoRE();
                    tipoDocumentoRE.setId(rs.getString("tido_id"));
                    tipoDocumentoRE.setNombre(rs.getString("tido_nombre"));
                    tipoDocumentoRE.setAbreviatura(rs.getString("tido_abreviatura"));
                    usuarioRE.setTipoDocumentoRE(tipoDocumentoRE);

                    usuarioRE.setDocumento(rs.getString("usua_documento"));
                    usuarioRE.setEmail(rs.getString("usua_email"));
                    usuarioRE.setUsuario(rs.getString("usua_usuario"));

                    lista.add(usuarioRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return lista;
    }

    /**
     * Método que consulta los registros correspondientes a la entidad: EDAA.USUARIO, filtrados por...
     *
     * @return lista de objetos UsuarioRE
     * @throws EdaaException EdaaException
     */
    @Override
    public Object listar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        UsuarioRE usuarioRE = (UsuarioRE) objeto;
        ResultSet rs = null;

        try {
            if (null == usuarioRE)
                return null;

            api.clear();
            api.addStrSql("usuario.buscarPorUsuario");
            api.addParameter(new Parameter(usuarioRE.getUsuario(), Types.VARCHAR));

            rs = (ResultSet) api.executeQuery();

            if (!rs.next()) return null;

            TipoDocumentoRE tipoDocumentoRE;

            usuarioRE = new UsuarioRE();
            usuarioRE.setId(rs.getString("usua_id"));
            usuarioRE.setPrimerNombre(rs.getString("usua_primernombre"));
            usuarioRE.setSegundoNombre(rs.getString("usua_segundonombre"));
            usuarioRE.setPrimerApellido(rs.getString("usua_primerapellido"));
            usuarioRE.setSegundoApellido(rs.getString("usua_segundoapellido"));
            usuarioRE.setUsuario(rs.getString("usua_usuario"));
            usuarioRE.setContrasena(rs.getString("usua_contrasena"));

            tipoDocumentoRE = new TipoDocumentoRE();
            tipoDocumentoRE.setId(rs.getString("tido_id"));
            tipoDocumentoRE.setNombre(rs.getString("tido_nombre"));
            tipoDocumentoRE.setAbreviatura(rs.getString("tido_abreviatura"));
            tipoDocumentoRE.setOk(true);
            usuarioRE.setTipoDocumentoRE(tipoDocumentoRE);

            usuarioRE.setEmail(rs.getString("usua_email"));
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "SQL buscar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "buscar( Object )", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return usuarioRE;
    }

    public void actualizarUsuarioYContrasena(Object objeto) throws EdaaException {
        UsuarioRE usuarioRE = (UsuarioRE) objeto;

        try {
            if (null != usuarioRE) {
                api.clear();
                api.addStrSql("usuario.actualizarUsuarioContrasena");
                api.addParameter(new Parameter(usuarioRE.getUsuario(), Types.VARCHAR));
                api.addParameter(new Parameter(Encriptacion.getStringMessageDigest(usuarioRE.getContrasena(), "MD5", 3), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getRegistradoPor(), Types.VARCHAR));
                api.addParameter(new Parameter(usuarioRE.getId(), Types.NUMERIC));
                usuarioRE.setOk(api.executeUpdate() > 0);
            }
        } catch (Exception e) {
            printException("actualizarUsuarioYContrasena(Object objeto)", e);
            throw new EdaaException(e.getClass().getName(), "UsuarioDAO", "actualizarUsuarioYContrasena(Object objeto)", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            System.out.println("Error ::> co.edu.unipamplona.ciadti.edaa.bdatos ::> clase UsuarioDAO ::> function public void close() ::> Exception ::>" + e.getMessage());
            printException("close()", e);
        }
    }
}
/*
 *  18/02/2021: JESÚS MIGUEL SIERRA VÁSQUEZ : CREACIÓN
 *
 */
