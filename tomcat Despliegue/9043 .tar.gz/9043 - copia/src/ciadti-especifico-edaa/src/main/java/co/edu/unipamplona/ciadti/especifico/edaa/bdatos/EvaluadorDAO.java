package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EvaluadorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.UsuarioRE;
import co.edu.unipamplona.ciadti.especifico.edaa.entidades.ValorRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

public class EvaluadorDAO implements IGeneralDAO, IPrintException {

    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "evaluador", "postgresql");

    /**
     * EvaluadorDAO     *
     *
     * @throws EdaaException EdaaException
     */
    public EvaluadorDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("EvaluadorDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de EvaluadorDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public EvaluadorDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("EvaluadorDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    // 21-02-2021 @: Jesús Sierra
    /**
     * Método que actualiza un evaluador que ha realizado una evaluación.
     * @param objeto - Datos del evaluador que ha realizado la evaluación.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public void actualizar(Object objeto) throws EdaaException
    {
        EvaluadorRE evaluadorRE = (EvaluadorRE) objeto;
        int res;

        try
        {
            if ( null != evaluadorRE )
            {
                api.clear();
                api.addStrSql("evaluador.actualizar");
                api.addParameter( new Parameter( evaluadorRE.getEstado(), Types.NUMERIC ) );
                api.addParameter( new Parameter( evaluadorRE.getObservacion(), Types.VARCHAR ) );
                api.addParameter( new Parameter( evaluadorRE.getPromedio(), Types.NUMERIC ) );
                api.addParameter( new Parameter( evaluadorRE.getRegistradoPor(), Types.VARCHAR ) );
                api.addParameter( new Parameter( evaluadorRE.getId(), Types.NUMERIC ) );
                res = api.executeUpdate();
                evaluadorRE.setOk( 1 == res );
            }
        } catch (SQLException e) {
            evaluadorRE.setOk(false);
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadorDAO", "SQL actualizar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadorDAO", "actualizar( Object )", e.getMessage());
        } finally {
            try {
                api.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {

        ArrayList<EvaluadorRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluador.listar");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EvaluadorRE evaluadorRE;
                while (rs.next()) {
                    evaluadorRE = new EvaluadorRE();
                    evaluadorRE.setId(rs.getString("evdr_id"));
                    evaluadorRE.setUsuaId(rs.getString("usua_id"));
                    evaluadorRE.setEvalId(rs.getString("eval_id"));
                    evaluadorRE.setFecha(rs.getTimestamp("evdr_fecha"));
                    evaluadorRE.setEstado(rs.getString("evdr_estado"));
                    evaluadorRE.setObservacion(rs.getString("evdr_observacion"));
                    evaluadorRE.setPromedio(rs.getDouble("avdr_promedio"));
                    evaluadorRE.setOk(true);
                    list.add(evaluadorRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        EvaluadorRE caracteristicaRE_BUS = (EvaluadorRE) objeto;
        ArrayList<EvaluadorRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluador.filtrar");
            api.addParameter(new Parameter(caracteristicaRE_BUS.getId(), Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EvaluadorRE evaluadorRE;
                while (rs.next()) {
                    evaluadorRE = new EvaluadorRE();
                    evaluadorRE.setId(rs.getString("eval_id"));
                    evaluadorRE.setUsuaId(rs.getString("usua_id"));
                    evaluadorRE.setEvalId(rs.getString("eval_fechainicio"));
                    evaluadorRE.setFecha(rs.getTimestamp("evdr_fecha"));
                    evaluadorRE.setEstado(rs.getString("eval_anoevaluacion"));
                    evaluadorRE.setObservacion(rs.getString("eval_tiempo"));
                    evaluadorRE.setPromedio(rs.getDouble("avdr_promedio"));
                    evaluadorRE.setOk(true);
                    list.add(evaluadorRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    // 23-02-2021 @: Jesús Sierra
    /**
     * Método que consulta un registro por id de usuario y id de evaluado en la entidad EDAA.EVALUADOR
     * @param objeto - Objeto con id de usuario y de evaluado a consultar.
     * @return Objeto con datos de evaluador.
     * @throws EdaaException - Excepción personalizada del sistema.
     */
    @Override
    public Object buscar( Object objeto ) throws EdaaException
    {
        EvaluadorRE evaluadorRE_Bus = (EvaluadorRE) objeto;
        EvaluadorRE evaluadorRE = null;
        ResultSet rs = null;

        try
        {
            if ( null == evaluadorRE_Bus ) {
                return null;
            }

            api.clear();
            api.addStrSql( "evaluador.buscar" );
            api.addParameter( new Parameter( evaluadorRE_Bus.getUsuaId(), Types.NUMERIC ) );
            api.addParameter( new Parameter( evaluadorRE_Bus.getEvalId(), Types.NUMERIC ) );
            rs = (ResultSet) api.executeQuery();

            if ( rs.next() )
            {
                evaluadorRE = new EvaluadorRE();
                evaluadorRE.setId(rs.getString("evdr_id"));
                evaluadorRE.setUsuaId(rs.getString("usua_id"));
                evaluadorRE.setEvalId(rs.getString("eval_id"));
                evaluadorRE.setFecha(rs.getTimestamp("evdr_fecha"));
                evaluadorRE.setEstado(rs.getString("evdr_estado"));
                evaluadorRE.setObservacion(rs.getString("evdr_observacion"));
                evaluadorRE.setPromedio(rs.getDouble("avdr_promedio"));

            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadorDAO", "SQL buscar( Object )", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace(System.out);
            throw new EdaaException(e.getClass().getName(), "EvaluadorDAO", "buscar( Object )", e.getMessage());

        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return evaluadorRE;
    }

    public Object buscar2(Object objeto) throws EdaaException {
        EvaluadorRE RE_BUS = (EvaluadorRE) objeto;
        ResultSet rs = null;
        EvaluadorRE evaluadorRE = null;
        try {
            api.clear();
            api.addStrSql("evaluador.buscar2");
            api.addParameter(new Parameter(RE_BUS.getId(), Types.NUMERIC));
//            api.addParameter( new Parameter( RE_BUS.getEvalId(), Types.NUMERIC ) );
            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                evaluadorRE = new EvaluadorRE();

                if (rs.next()) {
                    System.out.println("encuentra un evaluador");
                    evaluadorRE.setId(rs.getString("evdr_id"));
                    evaluadorRE.setUsuaId(rs.getString("usua_id"));
                    evaluadorRE.setEvalId(rs.getString("eval_id"));
//                    evaluadorRE.setFecha(rs.getString("evdr_fecha"));
                    evaluadorRE.setEstado(rs.getString("evdr_estado"));
                    evaluadorRE.setObservacion(rs.getString("evdr_observacion"));
                    evaluadorRE.setPromedio(rs.getDouble("avdr_promedio"));

                    evaluadorRE.setUsuarioRE(new UsuarioRE());
                    evaluadorRE.getUsuarioRE().setNombreCompleto(rs.getString("nombre_completo"));
                    evaluadorRE.getUsuarioRE().setDocumento(rs.getString("usua_documento"));
                    evaluadorRE.setOk(true);

                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "buscar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return evaluadorRE;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }

    public Object listarByEvaluado(Object objeto) throws EdaaException {
        EvaluadorRE RE_BUS = (EvaluadorRE) objeto;
        ArrayList<EvaluadorRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("evaluador.listarByEvaluado");
            api.addParameter(new Parameter(RE_BUS.getEvalId(), Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EvaluadorRE evaluadorRE;
                UsuarioRE usuario;
                while (rs.next()) {
                    evaluadorRE = new EvaluadorRE();
                    evaluadorRE.setId(rs.getString("evdr_id"));
                    evaluadorRE.setUsuaId(rs.getString("usua_id"));
                    evaluadorRE.setEvalId(rs.getString("eval_id"));
//                    evaluadorRE.setFecha(rs.getString("evdr_fecha"));
                    evaluadorRE.setEstado(rs.getString("evdr_estado"));
                    evaluadorRE.setObservacion(rs.getString("evdr_observacion"));
                    evaluadorRE.setPromedio(rs.getDouble("avdr_promedio"));
                    evaluadorRE.setOk(true);

                    usuario = new UsuarioRE();

                    usuario.setId(rs.getString("usua_id"));
                    usuario.setDocumento(rs.getString("usua_documento"));
                    usuario.setEmail(rs.getString("usua_email"));
                    usuario.setPrimerNombre(rs.getString("usua_primernombre"));
                    usuario.setSegundoNombre(rs.getString("usua_segundonombre"));
                    usuario.setPrimerApellido(rs.getString("usua_primerapellido"));
                    usuario.setSegundoApellido(rs.getString("usua_segundoapellido"));

                    evaluadorRE.setUsuarioRE(usuario);
                    list.add(evaluadorRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }
        return list;
    }
}
