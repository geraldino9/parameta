package co.edu.unipamplona.ciadti.especifico.edaa.bdatos;

import co.edu.unipamplona.ciadti.especifico.edaa.conexiones.DefinitionConnectionEdaa;

import co.edu.unipamplona.ciadti.especifico.edaa.entidades.EjecucionRE;
import co.edu.unipamplona.ciadti.especifico.edaa.excepciones.EdaaException;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IGeneralDAO;
import co.edu.unipamplona.ciadti.especifico.edaa.interfaces.IPrintException;
import especifico.accesoDatosApi.Api;
import especifico.accesoDatosApi.Parameter;
import especifico.interfaces.IDefinitionConnection;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;

public class EjecucionDAO implements IGeneralDAO, IPrintException {

    /**
     * Contiene el valor de la propiedad conexion
     */
    private IDefinitionConnection conexion;
    private final Api api = new Api("co/edu/unipamplona/ciadti/especifico/edaa", "ejecucion", "postgresql");

    /**
     EjecucionDAO     *
     * @throws EdaaException EdaaException
     */
    public EjecucionDAO() throws EdaaException {
        try {
            this.conexion = new DefinitionConnectionEdaa();
            api.setConnection(this.conexion);
        } catch (Exception e) {
            printException("CargoDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor()", e.getMessage(), e);
        }
    }

    /**
     * Crea una nueva instancia de EjecucionDAO, recibe un objeto
     *
     * @param conexion - IDefinitionConnection
     * @throws EdaaException EdaaException
     */
    public EjecucionDAO(Object conexion) throws EdaaException {
        try {
            if (conexion instanceof IDefinitionConnection) {
                this.conexion = (IDefinitionConnection) conexion;
                api.setConnection(this.conexion);
            }
        } catch (Exception e) {
            printException("EjecucionDAO()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "Constructor(Object conexion)", e.getMessage(), e);
        }
    }

    @Override
    public void insertar(Object objeto) throws EdaaException {

    }

    @Override
    public void actualizar(Object objeto) throws EdaaException {

    }

    @Override
    public void eliminar(Object objeto) throws EdaaException {

    }

    @Override
    public Object listar() throws EdaaException {

        ArrayList<EjecucionRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("ejecucion.listar");

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EjecucionRE ejecucionRE;
                while (rs.next()) {
                    ejecucionRE = new EjecucionRE();
                    ejecucionRE.setScriId(rs.getString("carg_id"));
                    ejecucionRE.setPaquId(rs.getString("carg_nombre"));
                    ejecucionRE.setEjec_fecha(rs.getString("carg_nombre"));
//                    ejecucionRE.setOk(true);
                    list.add(ejecucionRE);
                }
            }
        } catch (Exception e) {
            printException("listar()", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar()", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object listar(Object objeto) throws EdaaException {
        EjecucionRE caracteristicaRE_BUS = (EjecucionRE) objeto;
        ArrayList<EjecucionRE> list = null;
        ResultSet rs = null;
        try {
            api.clear();
            api.addStrSql("caracteristica.filtrar");
            api.addParameter(new Parameter("caracteristicaRE_BUS.getId()", Types.NUMERIC));

            rs = (ResultSet) api.executeQuery();

            if (rs.isBeforeFirst()) {
                list = new ArrayList<>();
                EjecucionRE ejecucionRE;
                while (rs.next()) {
                    ejecucionRE = new EjecucionRE();
                    ejecucionRE.setScriId(rs.getString("carg_id"));
                    ejecucionRE.setPaquId(rs.getString("carg_nombre"));
                    ejecucionRE.setEjec_fecha(rs.getString("carg_nombre"));
//                    ejecucionRE.setOk(true);
                    list.add(ejecucionRE);
                }
            }
        } catch (Exception e) {
            printException("listar(Object object)", e);
            throw new EdaaException(e.getClass().getName(), this.getClass().getName(), "listar(Object object)", e.getMessage());
        } finally {
            try {
                api.close();

                if (rs != null)
                    rs.close();
            } catch (Exception ex) {
                ex.printStackTrace(System.out);
            }
        }

        return list;
    }

    @Override
    public Object buscar(Object objeto) throws EdaaException {
        return null;
    }

    @Override
    public void close() {
        try {
            conexion.close();
        } catch (Exception e) {
            printException("close()", e);
        }
    }
}
