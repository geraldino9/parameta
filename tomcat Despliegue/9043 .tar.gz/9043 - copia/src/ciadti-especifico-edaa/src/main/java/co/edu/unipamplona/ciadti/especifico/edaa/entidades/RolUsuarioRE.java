package co.edu.unipamplona.ciadti.especifico.edaa.entidades;

import java.sql.Timestamp;

public class RolUsuarioRE {
    private String id;
    private String registradoPor;
    private Timestamp fechaRegistro;
    private boolean ok;

    private UsuarioRE usuarioRE;
    private RolRE rolRE;

    public RolUsuarioRE() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRegistradoPor() {
        return registradoPor;
    }

    public void setRegistradoPor(String registradoPor) {
        this.registradoPor = registradoPor;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public UsuarioRE getUsuarioRE() {
        return usuarioRE;
    }

    public void setUsuarioRE(UsuarioRE usuarioRE) {
        this.usuarioRE = usuarioRE;
    }

    public RolRE getRolRE() {
        return rolRE;
    }

    public void setRolRE(RolRE rolRE) {
        this.rolRE = rolRE;
    }
}
