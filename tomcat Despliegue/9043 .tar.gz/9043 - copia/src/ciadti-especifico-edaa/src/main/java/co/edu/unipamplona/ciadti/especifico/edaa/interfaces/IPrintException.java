package co.edu.unipamplona.ciadti.especifico.edaa.interfaces;

public interface IPrintException {
    default String printException(String function, String msg) {
        if (function == null || function.isEmpty()) {
            System.out.println("No se recibi\u00f3 el nombre de la funci\u00f3n");
        }

        System.out.println("Error ::> " + this.getClass().getName() + " ::> " + function + " ::> " + msg);
        return "Error ::> clase " + this.getClass().getName() + " ::> function " + function + " ::> " + msg;
    }

    default String printException(String function, Exception ex) {
        if (function == null || function.isEmpty()) {
            System.out.println("No se recibi\u00f3 el nombre de la funci\u00f3n");
        }

        String msgExc = "Error ::> clase " + this.getClass().getName() + " ::> function " + function;
        if (ex != null) msgExc += " ::> Exception ::> " + ex.getMessage();

        System.out.println(msgExc);
        if (ex != null) ex.printStackTrace(System.out);

        return msgExc;
    }
}